<?php

$msg = array();
require_once "./login.php";
if (isset($msg["AjaxError"])) {
    echo json_encode($msg);
    exit();
}

$queryId = $_POST['queryId'];
switch ($queryId) {
    case "getPsow" :
        $query = ""
                . "SELECT"
                . " `PSOW`.`Id`, "
                . " `PSOW`.`Version` as `Name` "
                . "FROM"
                . " `PSOW` "
                . "WHERE"
                . " `PSOW`.`BaseRouteId` = " . $_POST['route'] . " "
                . "ORDER BY `Id`";
        $result = mysql_query($query);
        if ($result) {
            $msg["PsowList"] = array();
            while ($row = mysql_fetch_assoc($result)) {
                $msg["PsowList"][] = $row;
            }
        } else {
            $msg['AjaxError'] = "$queryId: Ошибка в запросе.";
        }
        break;
    case "getPsowLine":
        $query = ""
                . "SELECT"
                . " `PSOW::Line`.`Id`,"
                . " `PSOW::Line`.`Position`,"
                . " `PSOW::Line`.`MaskLayerId`,"
                . " `Layer`.`Name` as `Name`, "
                . " `Layer`.`Layer` as `MaskLayer`,"
                . " `Grade`.`Name` as `Grade`,"
                . " `PSOW::Line`.`PM_Tonality` as `PMTonality` "
                . "FROM"
                . " `PSOW::Line` "
                . " LEFT JOIN `Layer::Mask` ON `Layer::Mask`.Id = `PSOW::Line`.`MaskLayerId`"
                . " LEFT JOIN `Layer` ON `Layer`.Id = `Layer::Mask`.`LayerId` "
                . " LEFT JOIN `Grade` ON `Grade`.Id = `PSOW::Line`.`PM_GradeId` "
                . " LEFT JOIN `Layer_BaseRoute_R` ON `Layer_BaseRoute_R`.LayerId = `Layer`.Id "
                . " LEFT JOIN `PSOW` ON `PSOW`.BaseRouteId = `Layer_BaseRoute_R`.BaseRouteId "
                . "WHERE"
                . " `PSOW::Line`.`PSOWId` = " . $_POST['psow'] . " AND "
                . " `PSOW`.Id  = " . $_POST['psow'] . " "
                . "ORDER BY Position";
        $result = mysql_query($query);
        if ($result) {
            $msg["PsowLineList"] = array();
            while ($row = mysql_fetch_assoc($result)) {
                //Базовые, Дополнительные, Dummy
                $queryCad = ""
                        . "SELECT DISTINCT"
                        . " `Layer`.`Layer`,"
                        . " `Layer::Merging`.Base,"
                        . " `Layer::Merging`.Dummy,"
                        . " `LayerIntermediate`.`Layer` as IntermdediateLayer "
                        . "FROM"
                        . " `Layer::Mask_Layer::Intermediate_R` "
                        . " LEFT JOIN `Layer::Intermediate_Layer::Merging_R` ON `Layer::Intermediate_Layer::Merging_R`.IntermediateLayerId = `Layer::Mask_Layer::Intermediate_R`.IntermediateLayerId "
                        . " LEFT JOIN `Layer::Intermediate` ON `Layer::Intermediate`.Id = `Layer::Intermediate_Layer::Merging_R`.IntermediateLayerId "
                        . " LEFT JOIN `Layer` as `LayerIntermediate` ON `LayerIntermediate`.Id = `Layer::Intermediate`.LayerId "
                        . " LEFT JOIN `Layer_BaseRoute_R` as `LayerIntermediateBaseRoute` ON `LayerIntermediateBaseRoute`.LayerId = `LayerIntermediate`.Id "
                        . " LEFT JOIN `PSOW` as `PSOWIntermediate` ON `PSOWIntermediate`.`BaseRouteId` = `LayerIntermediateBaseRoute`.`BaseRouteId`"
                        . " LEFT JOIN `Layer::Merging` ON `Layer::Merging`.Id = `Layer::Intermediate_Layer::Merging_R`.MergingLayerId "
                        . " LEFT JOIN `Layer::Cad` ON `Layer::Cad`.Id = `Layer::Merging`.CadLayerId "
                        . " LEFT JOIN `Layer` ON `Layer`.Id = `Layer::Cad`.LayerId "
                        . " LEFT JOIN `Layer_BaseRoute_R` ON `Layer_BaseRoute_R`.LayerId = `Layer`.Id "
                        . " LEFT JOIN `PSOW` ON `PSOW`.`BaseRouteId` = `Layer_BaseRoute_R`.`BaseRouteId`"
                        . "WHERE"
                        . " `Layer::Mask_Layer::Intermediate_R`.MaskLayerId = " . $row["MaskLayerId"] . " AND "
                        . " `PSOW`.Id = " . $_POST['psow'] . " AND "
                        . " `PSOWIntermediate`.Id = " . $_POST['psow'] . " "
                        . "ORDER BY `Layer`";

                $resultCad = mysql_query($queryCad);
                if ($resultCad) {
                    $row["CadLayer"] = "";
                    $row["DummyLayer"] = "";
                    $row["AdditionalLayer"] = "";
                    while ($rowCad = mysql_fetch_assoc($resultCad)) {
                        if ($rowCad["Base"] == 1) {
                            $row["CadLayer"][] = $rowCad["Layer"] . "<small data-smallInfo=\"true\"> (i-" . $rowCad['IntermdediateLayer'] . ")</small>";
                        }
                        if ($rowCad["Dummy"] == 1) {
                            $row["DummyLayer"][] = $rowCad["Layer"] . "<small data-smallInfo=\"true\"> (i-" . $rowCad['IntermdediateLayer'] . ")</small>";
                        }
                        if ($rowCad["Dummy"] == 0 && $rowCad["Base"] == 0) {
                            $row["AdditionalLayer"][] = $rowCad["Layer"] . "<small data-smallInfo=\"true\"> (i-" . $rowCad['IntermdediateLayer'] . ")</small>";
                        }
                    }
                    $row["CadLayer"] = implode(", ", $row["CadLayer"]);
                    $row["DummyLayer"] = implode(", ", $row["DummyLayer"]);
                    $row["AdditionalLayer"] = implode(", ", $row["AdditionalLayer"]);
                } else {
                    $row["CadLayer"] = "<div class=\"alert alert-danger\">Ошибка в запросе<br>$queryCad</div>";
                    $row["DummyLayer"] = "<div class=\"alert alert-danger\">Ошибка в запросе<br>$queryCad</div>";
                    $row["AdditionalLayer"] = "<div class=\"alert alert-danger\">Ошибка в запросе<br>$queryCad</div>";
                }
                //Forbidding
                $queryForb = ""
                        . "SELECT DISTINCT"
                        . " `Layer`.`Layer`,"
                        . " `LayerIntermediate`.`Layer` as `IntermdediateLayer`,"
                        . " `LayerMerging`.`Layer` as `MergingLayer` "
                        . "FROM"
                        . " `Layer::Mask_Layer::Intermediate_R` "
                        . " LEFT JOIN `Layer::Intermediate_Layer::Merging_R` ON `Layer::Intermediate_Layer::Merging_R`.IntermediateLayerId = `Layer::Mask_Layer::Intermediate_R`.IntermediateLayerId "
                        . " LEFT JOIN `Layer::Intermediate` ON `Layer::Intermediate`.Id = `Layer::Intermediate_Layer::Merging_R`.IntermediateLayerId "
                        . " LEFT JOIN `Layer` as `LayerIntermediate` ON `LayerIntermediate`.Id = `Layer::Intermediate`.LayerId "
                        . " LEFT JOIN `Layer_BaseRoute_R` as `LayerIntermediateBaseRoute` ON `LayerIntermediateBaseRoute`.LayerId = `LayerIntermediate`.Id "
                        . " LEFT JOIN `PSOW` as `PSOWIntermediate` ON `PSOWIntermediate`.`BaseRouteId` = `LayerIntermediateBaseRoute`.`BaseRouteId`"
                        . " LEFT JOIN `Layer::Merging_Layer::Forbidding_R` ON `Layer::Merging_Layer::Forbidding_R`.MergingLayerId = `Layer::Intermediate_Layer::Merging_R`.MergingLayerId "
                        . " LEFT JOIN `Layer::Merging` ON `Layer::Merging`.Id = `Layer::Merging_Layer::Forbidding_R`.MergingLayerId "
                        . " LEFT JOIN `Layer::Cad` as `LayerCadMerging` ON `LayerCadMerging`.Id = `Layer::Merging`.CadLayerId "
                        . " LEFT JOIN `Layer` as  `LayerMerging` on `LayerMerging`.Id = `LayerCadMerging`.LayerId "
                        . " LEFT JOIN `Layer_BaseRoute_R` as `LayerMergingBaseRoute` ON `LayerMergingBaseRoute`.LayerId = `LayerMerging`.Id"
                        . " LEFT JOIN `PSOW` as `PSOWMerging` ON `PSOWMerging`.BaseRouteId = `LayerMergingBaseRoute`.BaseRouteId "
                        . " LEFT JOIN `Layer::Forbidding` ON `Layer::Forbidding`.Id = `Layer::Merging_Layer::Forbidding_R`.`ForbiddingLayerId` "
                        . " LEFT JOIN `Layer::Cad` ON `Layer::Cad`.Id = `Layer::Forbidding`.CadLayerId "
                        . " LEFT JOIN `Layer` ON `Layer`.Id = `Layer::Cad`.LayerId "
                        . " LEFT JOIN `Layer_BaseRoute_R` ON `Layer_BaseRoute_R`.LayerId = `Layer`.Id "
                        . " LEFT JOIN `PSOW` ON `PSOW`.`BaseRouteId` = `Layer_BaseRoute_R`.`BaseRouteId` "
                        . "WHERE"
                        . " `Layer::Mask_Layer::Intermediate_R`.MaskLayerId = " . $row["MaskLayerId"] . " AND "
                        . " `PSOW`.Id = " . $_POST['psow'] . " AND"
                        . " `PSOWIntermediate`.Id = " . $_POST['psow'] . " AND "
                        . " `PSOWMerging`.Id = " . $_POST['psow'] . " "
                        . "ORDER BY `Layer`";
                $resultForb = mysql_query($queryForb);
                if ($resultForb) {
                    $row["ForbiddingLayer"] = "";
                    while ($rowForb = mysql_fetch_assoc($resultForb)) {
                        $row["ForbiddingLayer"][] = $rowForb["Layer"]. "<small data-smallInfo=\"true\"> (c-".$rowForb['MergingLayer'].", i-" . $rowForb['IntermdediateLayer'] . ")</small>";
                    }
                    $row["ForbiddingLayer"] = implode(", ", $row["ForbiddingLayer"]);
                } else {
                    $row["ForbiddingLayer"] = "<div class=\"alert alert-danger\">Ошибка в запросе<br>$queryForb</div>";
                }
                //Intermediate
                $queryInter = ""
                        . "SELECT DISTINCT"
                        . " `Layer`.`Layer`,"
                        . " `Layer::Intermediate`.`Mark`,"
                        . " `Layer::Intermediate`.`Density` "
                        . "FROM"
                        . " `Layer::Mask_Layer::Intermediate_R` "
                        . " LEFT JOIN `Layer::Intermediate_Layer::Merging_R` ON `Layer::Intermediate_Layer::Merging_R`.IntermediateLayerId = `Layer::Mask_Layer::Intermediate_R`.IntermediateLayerId "
                        . " LEFT JOIN `Layer::Intermediate` ON `Layer::Intermediate`.Id = `Layer::Mask_Layer::Intermediate_R`.IntermediateLayerId"
                        . " LEFT JOIN `Layer` ON `Layer`.Id = `Layer::Intermediate`.LayerId "
                        . " LEFT JOIN `Layer_BaseRoute_R` ON `Layer_BaseRoute_R`.LayerId = `Layer`.Id "
                        . " LEFT JOIN `PSOW` ON `PSOW`.`BaseRouteId` = `Layer_BaseRoute_R`.`BaseRouteId`"
                        . "WHERE"
                        . " `Layer::Mask_Layer::Intermediate_R`.MaskLayerId = " . $row["MaskLayerId"] . " AND "
                        . " `PSOW`.Id = " . $_POST['psow'] . " "
                        . "ORDER BY `Layer`";
                $resultInter = mysql_query($queryInter);
                if ($resultInter) {
                    $row["IntermediateLayer"] = "";
                    $row["IntermediateMarkLayer"] = "";
                    $row["IntermediateDensityLayer"] = "";
                    while ($rowInter = mysql_fetch_assoc($resultInter)) {
                        if ($rowInter["Mark"] == 1 && $rowInter["Density"] == 1) {
                            $row["IntermediateMarkLayer"][] = $rowInter["Layer"];
                            $row["IntermediateDensityLayer"][] = $rowInter["Layer"];
                        } else if ($rowInter["Mark"] == 1) {
                            $row["IntermediateMarkLayer"][] = $rowInter["Layer"];
                        } else if ($rowInter["Density"] == 1) {
                            $row["IntermediateDensityLayer"][] = $rowInter["Layer"];
                        } else {
                            $row["IntermediateLayer"][] = $rowInter["Layer"];
                        }
                    }
                    $row["IntermediateLayer"] = implode(", ", $row["IntermediateLayer"]);
                    $row["IntermediateMarkLayer"] = implode(", ", $row["IntermediateMarkLayer"]);
                    $row["IntermediateDensityLayer"] = implode(", ", $row["IntermediateDensityLayer"]);
                } else {
                    $row["IntermediateLayer"] = "<div class=\"alert alert-danger\">Ошибка в запросе<br>$queryInter</div>";
                }
                $msg["PsowLineList"][] = $row;
            }
        } else {
            $msg['AjaxError'] = "$queryId: Ошибка в запросе.";
        }

        $query = ""
                . "SELECT"
                . " `Layer`.Layer "
                . "FROM"
                . " `PSOW`"
                . " LEFT JOIN `Layer_BaseRoute_R` ON `Layer_BaseRoute_R`.BaseRouteId = `PSOW`.BaseRouteId "
                . " LEFT JOIN `Layer` ON `Layer`.Id = `Layer_BaseRoute_R`.LayerId"
                . " LEFT JOIN `Layer::Cad` ON `Layer::Cad`.LayerId = `Layer`.Id "
                . " LEFT JOIN `Layer::Suspended` ON `Layer::Suspended`.CadLayerId = `Layer::Cad`.`Id` "
                . "WHERE"
                . " `PSOW`.`Id` = " . $_POST['psow'] . " AND "
                . " `Layer::Cad`.Id IS NOT NULL AND "
                . " `Layer::Suspended`.Id IS NOT NULL "
                . "ORDER BY `Layer` ";

        $result = mysql_query($query);
        if ($result) {
            $msg["SuspendedLayerList"] = array();
            while ($row = mysql_fetch_assoc($result)) {
                $msg["SuspendedLayerList"][] = $row['Layer'];
            }
            $msg["SuspendedLayerList"] = implode(", ", $msg["SuspendedLayerList"]);
        } else {
            $msg['AjaxError'] = "$queryId: Ошибка в запросе.";
        }
        break;
    case "getRoute":
        $query = ""
                . "SELECT"
                . " `BaseRoute`.`Id`, "
                . " `BaseRoute`.`Name`, "
                . " `BaseRoute`.`Revision` "
                . "FROM"
                . " `BaseRoute` "
                . "WHERE"
                . " `BaseRoute`.`TechnologyId` = " . $_POST['technology'] . " "
                . "ORDER BY `Name`, `Revision`";
        $result = mysql_query($query);
        if ($result) {
            $msg["RouteList"] = array();
            while ($row = mysql_fetch_assoc($result)) {
                $tmpRow["Id"] = $row["Id"];
                $tmpRow["Name"] = $row["Name"] . " <small>revision: " . $row['Revision'] . "</small>";
                $msg["RouteList"][] = $tmpRow;
            }
        } else {
            $msg['AjaxError'] = "$queryId: Ошибка в запросе.";
        }
        break;
    case "getTechnologyList":
        $query = ""
                . "SELECT"
                . " `Technology`.`Id`,"
                . " `Technology`.`Name` "
                . "FROM"
                . " `Technology` "
                . "ORDER BY `Name`";
        $result = mysql_query($query);
        if ($result) {
            $msg["TechnologyList"] = array();
            while ($row = mysql_fetch_assoc($result)) {
                $msg["TechnologyList"][] = $row;
            }
        } else {
            $msg['AjaxError'] = "$queryId: Ошибка в запросе.";
        }
        break;
    default:
        $msg['AjaxError'] = "Не корректный ключ запроса.";
}

echo json_encode($msg);
?>
