/*global hideSmallComment, checkboxHideSmallInfo, suspendedLayersBaseRouteDiv, suspendedLayersBaseRouteBody, psowCheckbox, formPsow, formRoutes, formTechnology, privateTermsOfReferenceTable, hideEmptyRow, showNameOptions, routesCheckbox, technologySelect, modalAlertBody, modalAlert, privateTermsOfReferencePage, pathAjax*/

function alertMsg(text) {
    modalAlertBody.innerHTML = text;
    $('#modalAlert').modal('show');
}

function clearPsow() {
    psowCheckbox.innerHTML = "";
    var label = document.createElement("label");
    label.innerHTML = "ЧТЗ:";
    psowCheckbox.appendChild(label);
    clearTable();
}

function clearRoute() {
    routesCheckbox.innerHTML = "";
    var label = document.createElement("label");
    label.innerHTML = "Маршруты:";
    routesCheckbox.appendChild(label);
    clearPsow();
}

function clearTable() {
    suspendedLayersBaseRouteDiv.hidden = true;
    suspendedLayersBaseRouteBody.innerHTML = true;
    privateTermsOfReferenceTable.children[1].innerHTML = "";
    privateTermsOfReferenceTable.hidden = true;
    hideSmallComment.hidden = true;
}

function createBaseRouteCheckBox(parentForm, checkboxId, checkboxValue, labelText, checkboxFunction, checkboxName) {
    var div = document.createElement("div");
    var input = document.createElement("input");
    var label = document.createElement("label");

    div.setAttribute("class", "custom-control custom-radio");
    input.type = "radio";
    input.setAttribute("class", "custom-control-input");
    input.id = checkboxId;
    input.value = checkboxValue;
    input.name = checkboxName;
    input.setAttribute("onchange", checkboxFunction);
    label.setAttribute("class", "custom-control-label");
    label.setAttribute("for", checkboxId);
    label.innerHTML = labelText;

    parentForm.appendChild(div);
    div.appendChild(input);
    div.appendChild(label);
}

function getTechnologyList() {
    clearRoute();
    technologySelect.innerHTML = "";
    technologySelect.disabled = true;

    var formData = new FormData();
    formData.append('queryId', 'getTechnologyList');
    $.ajax({
        url: pathAjax.value,
        type: 'POST',
        data: formData,
        processData: false,
        contentType: false,
        success: function (data) {
            try {
                var jsonData = JSON.parse(data);
                if (typeof jsonData.AjaxError !== "undefined") {
                    alertMsg(jsonData.AjaxError);
                } else if (typeof jsonData.TechnologyList !== "undefined") {
                    technologySelect.innerHTML = "";
                    var opt = document.createElement("option");
                    opt.text = "...";
                    opt.selected = true;
                    technologySelect.appendChild(opt);
                    for (var key in jsonData.TechnologyList) {
                        var opt = document.createElement("option");
                        opt.text = jsonData.TechnologyList[key].Name;
                        opt.value = jsonData.TechnologyList[key].Id;
                        technologySelect.appendChild(opt);
                    }
                    technologySelect.disabled = false;
                } else {
                    alertMsg("Не корректный ответ от сервера");
                }
            } catch (e) {
                alertMsg("Ошибка в структуре ответа от сайта:<br>" + e);
            }
        },
        error: function (request, status, error) {
            alertMsg("Ошибка при обращении к серверу:<br>error:" + error + "<br>status:" + status);
        }
    });
}

function getRoute() {
    clearRoute();
    var formData = new FormData(formTechnology);
    formData.append('queryId', 'getRoute');
    if (formData.get("technology") == "...") {
        return false;
    }
    $.ajax({
        url: pathAjax.value,
        type: 'POST',
        data: formData,
        processData: false,
        contentType: false,
        success: function (data) {
            try {
                var jsonData = JSON.parse(data);
                if (typeof jsonData.AjaxError !== "undefined") {
                    alertMsg(jsonData.AjaxError);
                } else if (typeof jsonData.RouteList !== "undefined") {
                    if (Object.keys(jsonData.RouteList).length > 0) {
                        for (var key in jsonData.RouteList) {
                            createBaseRouteCheckBox(routesCheckbox, "baseRoute_" + jsonData.RouteList[key].Id, jsonData.RouteList[key].Id, jsonData.RouteList[key].Name, "getPsow()", "route");
                        }
                    } else {
                        var div = document.createElement("div");
                        div.setAttribute("class", "alert alert-warning");
                        div.innerHTML = "Данных нет";
                        routesCheckbox.appendChild(div);
                    }
                } else {
                    alertMsg("Не корректный ответ от сервера");
                }
            } catch (e) {
                alertMsg("Ошибка в структуре ответа от сайта:<br>" + e);
            }
        },
        error: function (request, status, error) {
            alertMsg("Ошибка при обращении к серверу:<br>error:" + error + "<br>status:" + status);
        }
    });
}

function getPsow() {

    clearPsow();
    var formData = new FormData(formRoutes);
    formData.append('queryId', 'getPsow');
    if (!formData.has("route")) {
        return false;
    }
    $.ajax({
        url: pathAjax.value,
        type: 'POST',
        data: formData,
        processData: false,
        contentType: false,
        success: function (data) {
            try {
                var jsonData = JSON.parse(data);
                if (typeof jsonData.AjaxError !== "undefined") {
                    alertMsg(jsonData.AjaxError);
                } else if (typeof jsonData.PsowList !== "undefined") {
                    if (Object.keys(jsonData.PsowList).length > 0) {
                        for (var key in jsonData.PsowList) {
                            createBaseRouteCheckBox(psowCheckbox, "psow_" + jsonData.PsowList[key].Id, jsonData.PsowList[key].Id, jsonData.PsowList[key].Name, "getPsowLine()", "psow");
                        }
                    } else {
                        var div = document.createElement("div");
                        div.setAttribute("class", "alert alert-warning");
                        div.innerHTML = "Данных нет";
                        psowCheckbox.appendChild(div);
                    }
                } else {
                    alertMsg("Не корректный ответ от сервера");
                }
            } catch (e) {
                alertMsg("Ошибка в структуре ответа от сайта:<br>" + e);
            }
        },
        error: function (request, status, error) {
            alertMsg("Ошибка при обращении к серверу:<br>error:" + error + "<br>status:" + status);
        }
    });
}

function getPsowLine() {
    clearTable();
    var formData = new FormData(formPsow);
    formData.append('queryId', 'getPsowLine');
    if (!formData.has("psow")) {
        return false;
    }
    $.ajax({
        url: pathAjax.value,
        type: 'POST',
        data: formData,
        processData: false,
        contentType: false,
        success: function (data) {
            try {
                var jsonData = JSON.parse(data);
                if (typeof jsonData.AjaxError !== "undefined") {
                    alertMsg(jsonData.AjaxError);
                } else if (typeof jsonData.PsowLineList !== "undefined" && typeof jsonData.SuspendedLayerList !== "undefined") {
                    if (Object.keys(jsonData.PsowLineList).length > 0) {
                        var tbody = privateTermsOfReferenceTable.children[1];
                        for (var key in jsonData.PsowLineList) {
                            var row = tbody.insertRow(tbody.rows.length);
                            var cellId = row.insertCell(row.length);
                            var cellPosition = row.insertCell(row.length);
                            var cellName = row.insertCell(row.length);
                            var cellMaskLayer = row.insertCell(row.length);
                            var cellCadLayer = row.insertCell(row.length);
                            var cellDummyLayer = row.insertCell(row.length);
                            var cellAdditionalLayer = row.insertCell(row.length);
                            var cellForbiddingLayer = row.insertCell(row.length);
                            var cellIntermediateMark = row.insertCell(row.length);
                            var cellIntermediateDensity = row.insertCell(row.length);
                            var cellIntermediateLayer = row.insertCell(row.length);
                            var cellPMTonality = row.insertCell(row.length);
                            var cellGrade = row.insertCell(row.length);


                            cellId.innerHTML = jsonData.PsowLineList[key].Id;
                            cellPosition.innerHTML = jsonData.PsowLineList[key].Position;
                            cellName.innerHTML = jsonData.PsowLineList[key].Name;
                            cellMaskLayer.innerHTML = jsonData.PsowLineList[key].MaskLayer;
                            cellCadLayer.innerHTML = jsonData.PsowLineList[key].CadLayer;
                            cellDummyLayer.innerHTML = jsonData.PsowLineList[key].DummyLayer;
                            cellAdditionalLayer.innerHTML = jsonData.PsowLineList[key].AdditionalLayer;
                            cellForbiddingLayer.innerHTML = jsonData.PsowLineList[key].ForbiddingLayer;
                            cellIntermediateMark.innerHTML = jsonData.PsowLineList[key].IntermediateMarkLayer;
                            cellIntermediateDensity.innerHTML = jsonData.PsowLineList[key].IntermediateDensityLayer;
                            cellIntermediateLayer.innerHTML = jsonData.PsowLineList[key].IntermediateLayer;
                            cellGrade.innerHTML = jsonData.PsowLineList[key].Grade;
                            cellPMTonality.innerHTML = jsonData.PsowLineList[key].PMTonality;

                        }
                        suspendedLayersBaseRouteDiv.hidden = false;
                        suspendedLayersBaseRouteBody.innerHTML = "Приостановленные слои для выбранного маршрута:<strong> " + jsonData.SuspendedLayerList + "</strong>";
                        privateTermsOfReferenceTable.hidden = false;
                        hideSmallComment.hidden = false;
                        hideSmallInfo();
                        
                    } else {
                        alertMsg("Данный в базе нет.");
                    }
                } else {
                    alertMsg("Не корректный ответ от сервера");
                }
            } catch (e) {
                alertMsg("Ошибка в структуре ответа от сайта:<br>" + e);
            }
        },
        error: function (request, status, error) {
            alertMsg("Ошибка при обращении к серверу:<br>error:" + error + "<br>status:" + status);
        }
    });
}

function hideSmallInfo() {
    var smallCollection = document.querySelectorAll("[data-smallInfo]");
    for (var i in smallCollection) {
        if (smallCollection.hasOwnProperty(i)) {
            smallCollection[i].hidden = checkboxHideSmallInfo.checked;
        }
    }
}


window.onload = function () {
    privateTermsOfReferencePage.setAttribute("class", "nav-item nav-link active");
    technologySelect.disabled = true;
    getTechnologyList();
}
