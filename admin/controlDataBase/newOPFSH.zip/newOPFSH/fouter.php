<?php
echo " 
        <!-- Optional JavaScript -->
        <!-- jQuery first, then Popper.js, then Bootstrap JS -->        
        <script src='$host/js/jquery.min.js'></script>
        <script src='$host/js/popper.min.js'></script>
        <script src='$host/js/bootstrap.min.js'></script>
         <!-- Latest compiled and minified JavaScript -->
        <script src='$host/plugins/bootstrap-select-1.13.14/dist/js/bootstrap-select.min.js'></script>

        <!-- (Optional) Latest compiled and minified JavaScript translation files -->
        <script src='$host/plugins/bootstrap-select-1.13.14/dist/js/i18n/defaults-*.min.js'></script>
    </body>
</html>";
?>