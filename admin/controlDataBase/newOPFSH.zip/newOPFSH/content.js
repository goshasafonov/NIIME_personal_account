window.onload = function () {
    indexPage.setAttribute("class","nav-item nav-link active");
}
   