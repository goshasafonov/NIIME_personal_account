<?php

defined('APP') or die('Access denied!');
echo " 
<!doctype html>
<html lang='en'>
    <head>
        <!-- Required meta tags -->
        <meta charset='utf-8'>
        <meta http-equiv = 'X-UA-Compatible' content = 'IE = edge'>
        <meta name='viewport' content='width=device-width, initial-scale=1, shrink-to-fit=no'>

        <!-- Bootstrap CSS -->        
        <link href='$host/css/bootstrap.min.css' type='text/css' rel='stylesheet'>
        <link href='$host/css/main.css' type='text/css' rel='stylesheet'>
        <link href='$host/plugins/MaterialDesign-Webfont-master/css/materialdesignicons.css' type='text/css' rel='stylesheet'>
        
        <!-- Latest compiled and minified CSS -->
        <link rel='stylesheet' href='$host/plugins/bootstrap-select-1.13.14/dist/css/bootstrap-select.min.css'>

        
        
        <title>База данных ЛК-2.0.0</title>
    </head>
    <body>
        <div class='contatiner-fluid'>
            <nav class='navbar navbar-expand-lg navbar-dark bg-dark fixed-top'>
                <div class='container'>
                    <div class='collapse navbar-collapse'>
                        <div class='navbar-nav'>
                            <a class='nav-item nav-link' href='$host' id='indexPage'>Главная</a>
                            <a class='nav-item nav-link' href='$host/technology' id='technologyPage'>Технологии</a>
                            <a class='nav-item nav-link' href='$host/layerManagment' id='layerManagmentPage' disabled>Управление слоями</a>
                            <a class='nav-item nav-link' href='$host/layers' id='layersPage' disabled>Слои</a>
                            <a class='nav-item nav-link' href='$host/privateTermsOfReference' id='privateTermsOfReferencePage' disabled>ЧТЗ</a>
                            <a class='nav-item nav-link' href='$host/teg' id='tegPage'>Тeg</a>
                            <a class='nav-item nav-link' href='$host/releaseNotes' id='releaseNotesPage'>RealseNotes</a>
                        </div>
                    </div>
                </div>
            </nav> 
        </div>";
?>
