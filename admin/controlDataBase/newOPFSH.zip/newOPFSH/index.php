<?php
    define('APP', true);
    include_once ("./config.php");    
    include_once ("./header.php");
    $page = file_get_contents("./page.html");
    $page = str_replace("%\$host%", $host, $page);
    $page = str_replace("%\$versionSite%", $versionSite, $page);
    $page = $page . "<script src='$host/content.js'></script>";
    echo $page;
    include_once ("./fouter.php");
?>