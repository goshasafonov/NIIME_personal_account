/*global managePanelChange_formControlTeg_uiSelectUi, managePanelChange_formControlTeg_rowUI, managePanelChange_formControlTeg_tableTegCells, managePanelChange_formControlTeg_rowTegCells_selectCells, managePanelChange_formControlTeg_rowTegCells, managePanelChange_formControlTeg_routesSelectRoute, managePanelChange_formControlTeg_rowRoutes, managePanelChange_formControlTeg_primaryCell, managePanelChange_formControlTeg_locked, managePanelChange_formControlTeg_orientation, managePanelChange_formControlTeg_sizeY, managePanelChange_formControlTeg_sizeX, managePanelChange_formControlTeg_md5, managePanelChange_formControlTeg_path, managePanelChange_formControlTeg_id, managePanelCreate_form_divRoute, managePanelCreate_form_primaryCell, managePanelCreate_form_cellsTable, managePanelChange_formSearchTeg, managePanelChange_formControlTeg, managePanelChange_formSearchTeg_ui, managePanelChange_formSearchTeg_route, managePanelChange_formSearchTeg_technology, managePanelChange_formSearchTeg_id, managePanelCreate_form, managePanelCreate_form_orientation, managePanelCreate_form_sizeY, managePanelCreate_form_sizeX, managePanelCreate_form_md5, managePanelCreate_form_path, modalTegInfo_cells, modalTegInfo_ui, modalTegInfo_routes, modalTegInfo_creationDate, modalTegInfo_expirationDate, modalTegInfo_primaryCell, modalTegInfo_md5, modalTegInfo_orientation, modalTegInfo_size, modalTegInfo_name, modalTegInfo_path, modalTegInfo_id, modalTegInfoTitle, tegTable, modalAlertBody, tegPage, pathAjax*/

/*
 *Общи функции
 */

function clearSelectPicker(el) {
    el.innerHTML = "";
    $('#' + el.id).selectpicker('refresh');
}

function alertMsg(text) {
    modalAlertBody.innerHTML = text;
    $('#modalAlert').modal('show');
}

function appendOpt(select, val, text) {
    var option = document.createElement("option");
    option.value = val;
    option.text = text;
    select.appendChild(option);
}

function createEmptyOptionForSelect(select, val, text) {
    select.innerHTML = "";
    appendOpt(select, val, text);
}

function createInputGroup(parentEl, text, val, btnId, onclk) {
    var divIG = document.createElement("div");
    var divIGA = document.createElement("div");
    var input = document.createElement("input");
    var button = document.createElement("button");

    divIG.setAttribute("class", "input-group mb-3");
    input.type = "text";
    input.disabled = true;
    input.value = text;
    input.setAttribute("class", "form-control");
    input.setAttribute("placeholder", "");
    input.setAttribute("aria-label", "");
    input.setAttribute("aria-describedby", btnId);
    divIGA.setAttribute("class", "input-group-append");
    button.type = "button";
    button.id = btnId;
    button.setAttribute("class", "btn btn-outline-danger");
    button.setAttribute("onclick", onclk);
    button.value = val;
    button.innerHTML = "Удалить";

    parentEl.appendChild(divIG);
    divIG.appendChild(input);
    divIG.appendChild(divIGA);
    divIGA.appendChild(button);
}

function insertSpinner(el) {
    el.innerHTML = "";

    var div = document.createElement("div");
    var span = document.createElement("span");

    div.setAttribute("class", "spinner-border spinner-border-sm text-primary");
    div.setAttribute("role", "status");
    span.setAttribute("class", "sr-only");
    span.innerHTML = "Loading...";

    el.appendChild(div);
    div.appendChild(span);
}

function isInt_number(v) {
    var num = /^-?[0-9]+$/;
    return num.test(v);
}

function isFloat_number(v) {
    var num = /^[-+]?[0-9]+\.[0-9]+$/;
    return num.test(v);
}

function renameLabelInputFile(el) {
    var fileName = el.value;
    var label = el.parentNode.children[1];
    if (fileName != "") {
        label.innerHTML = el.files[0].name;
    } else {
        label.innerHTML = "Выберите teg.ini";
    }

    managePanelCreate_form_cellsTable.children[1].innerHTML = "";
    managePanelCreate_form_cellsTable.hidden = true;
}

function selectpickerRefresh(id, text, arr, keyFlag, val) {
    if (document.getElementById(id)) {
        select = document.getElementById(id);
        createEmptyOptionForSelect(select, "", text);
        for (var key in arr) {
            if (keyFlag == 1) {
                appendOpt(select, arr[key], arr[key]);
            } else if (keyFlag == 2) {
                appendOpt(select, arr[key].Id, arr[key].Name);
            } else {
                appendOpt(select, key, arr[key]);
            }
        }
        select.value = val;
        $('#' + id).selectpicker('refresh');
        $('#' + id).selectpicker('val', val);
    }
}

Element.prototype.documentOffsetTop = function () {
    return this.offsetTop + (this.offsetParent ? this.offsetParent.documentOffsetTop() : 0);
};

window.onload = function () {
    tegPage.setAttribute("class", "nav-item nav-link active");
    getTeg();
};

/*
 *Общая сборка по TEG 
 */

function createCustomRouteCheckBox(div, arr) {
    var divC = document.createElement("div");
    var input = document.createElement("input");
    var label = document.createElement("label");

    divC.setAttribute("class", "custom-control custom-checkbox");

    input.id = div.id + "_route_" + arr.Id;
    input.name = "route[]";
    input.type = "checkbox";
    input.value = arr.Id;
    input.setAttribute("class", "custom-control-input");

    label.setAttribute("class", "custom-control-label");
    label.setAttribute("for", input.id);
    label.innerHTML = arr.Name;

    div.appendChild(divC);
    divC.appendChild(input);
    divC.appendChild(label);
}

function createTeg() {
    var formData = new FormData(managePanelCreate_form);
    formData.append('queryId', 'createTeg');

    var checkForm = new Array();
    //контроль Path
    if (formData.get("path") == "") {
        checkForm.push("Необходимо заполнить путь к тегу!");
    }
    //контроль SizeX
    if (formData.get("sizeX") == "") {
        checkForm.push("Необходимо заполнить размер тега по X");
    } else if (!isInt_number(formData.get("sizeX")) && !isFloat_number(formData.get("sizeX"))) {
        checkForm.push("Не корректное число размера тега по X");
    }
    //контроль SizeY
    if (formData.get("sizeY") == "") {
        checkForm.push("Необходимо заполнить размер тега по Y");
    } else if (!isInt_number(formData.get("sizeY")) && !isFloat_number(formData.get("sizeY"))) {
        checkForm.push("Не корректное число размера тега по Y");
    }
    //контроль Orientation
    if (formData.get("orientation") == "") {
        checkForm.push("Необходимо выбрать ориентацию тега!");
    }
    //контроль тестовых линеек
    if (!formData.has("tegCellId[]")) {
        checkForm.push("Необходимо указать минимум одну тестовою полосу!");
    }
    //контроль опорной линейки
    if (formData.get("primaryCell") == "") {
        checkForm.push("Необходимо указать опорную тестовую полосу!");
    }
    //контроль маршрута
    if (!formData.has("route[]")) {
        checkForm.push("Необходимо указать минимум один маршрут!");
    }
    if (checkForm.length > 0) {
        alertText = "Внимание ошибка в форме:<ul>";
        for (let check of checkForm) {
            alertText = alertText + "<li>" + check + "</li>";
        }
        alertText = alertText + "<ul>";
        alertMsg(alertText);
        return false;
    }


    $.ajax({
        url: pathAjax.value,
        type: 'POST',
        data: formData,
        processData: false,
        contentType: false,
        success: function (data) {
            try {
                var jsonData = JSON.parse(data);
                if (typeof jsonData.AjaxError !== "undefined") {
                    alertMsg(jsonData.AjaxError);
                } else if (typeof jsonData.Success !== "undefined") {
                    alertMsg("Teg is good: "+ jsonData.Success);
                    managePanelCreate_form_cellsTable.children[1].innerHTML = "";
                    initalStateManagePanelCreateForm();
                    getTeg();
                } else {
                    alertMsg("Не корректный ответ от сервера");
                }
            } catch (e) {
                alertMsg("Ошибка в структуре ответа от сайта:<br>" + e);
            }
        },
        error: function (request, status, error) {
            alertMsg("Ошибка при обращении к серверу:<br>error:" + error + "<br>status:" + status);
        }
    });
}

function deleteTeg(id) {
    if (!confirm("Удалить Тег?")) {
        return false;
    }
    var formData = new FormData();
    formData.append('queryId', 'deleteTeg');
    formData.append('tegId', id);
    $.ajax({
        url: pathAjax.value,
        type: 'POST',
        data: formData,
        processData: false,
        contentType: false,
        success: function (data) {
            try {
                var jsonData = JSON.parse(data);
                if (typeof jsonData.AjaxError !== "undefined") {
                    alertMsg(jsonData.AjaxError);
                } else if (typeof jsonData.Success !== "undefined") {
                    getTeg();
                } else {
                    alertMsg("Не корректный ответ от сервера");
                }
            } catch (e) {
                alertMsg("Ошибка в структуре ответа от сайта:<br>" + e);
            }
        },
        error: function (request, status, error) {
            alertMsg("Ошибка при обращении к серверу:<br>error:" + error + "<br>status:" + status);
        }
    });
}

function getFiltrSearchTeg(id) {
    managePanelChange_formSearchTeg.children[0].disabled = true;
    initalStateManagePanelChangeFormSearch();
    var formData = new FormData();
    formData.append('queryId', 'getFiltrSearchTeg');

    if (typeof id !== "undefined") {
        formData.append('id', id);
    } else {
        formData.append('id', '');
    }

    $.ajax({
        url: pathAjax.value,
        type: 'POST',
        data: formData,
        processData: false,
        contentType: false,
        success: function (data) {
            try {
                var jsonData = JSON.parse(data);
                if (typeof jsonData.AjaxError !== "undefined") {
                    alertMsg(jsonData.AjaxError);
                } else if (typeof jsonData.Tegs !== "undefined") {
                    //Id
                    selectpickerRefresh("managePanelChange_formSearchTeg_id", "№", jsonData.Tegs, 0, jsonData.Id);
                    if (jsonData.Id != "") {
                        getTegInfoForChangeFormControl();
                    }
                    managePanelChange_formSearchTeg.children[0].disabled = false;
                } else {
                    alertMsg("Не корректный ответ от сервера");
                }
            } catch (e) {
                alertMsg("Ошибка в структуре ответа от сайта:<br>" + e);
            }
        },
        error: function (request, status, error) {
            alertMsg("Ошибка при обращении к серверу:<br>error:" + error + "<br>status:" + status);
        }
    });
}

function getPrimaryCellForSelectPicker(sel) {

    var formData = new FormData();
    formData.append('queryId', 'getPrimaryCellsTeg');
    formData.append('cellId', sel.value);
    clearSelectPicker(sel);
    $.ajax({
        url: pathAjax.value,
        type: 'POST',
        data: formData,
        processData: false,
        contentType: false,
        success: function (data) {
            try {
                var jsonData = JSON.parse(data);
                if (typeof jsonData.AjaxError !== "undefined") {
                    alertMsg(jsonData.AjaxError);
                } else if (typeof jsonData.Cells !== "undefined") {
                    selectpickerRefresh(sel.id, "Ячейка ...", jsonData.Cells, 0, jsonData.CellId);
                } else {
                    alertMsg("Не корректный ответ от сервера");
                }
            } catch (e) {
                alertMsg("Ошибка в структуре ответа от сайта:<br>" + e);
            }
        },
        error: function (request, status, error) {
            alertMsg("Ошибка при обращении к серверу:<br>error:" + error + "<br>status:" + status);
        }
    });
}

function getTeg() {
    tegTable.children[1].innerHTML = "";
    var formData = new FormData();
    formData.append('queryId', 'getTegList');
    $.ajax({
        url: pathAjax.value,
        type: 'POST',
        data: formData,
        processData: false,
        contentType: false,
        success: function (data) {
            try {
                var jsonData = JSON.parse(data);
                if (typeof jsonData.AjaxError !== "undefined") {
                    alertMsg(jsonData.AjaxError);
                } else if (typeof jsonData.TegList !== "undefined") {
                    var tbody = tegTable.children[1];
                    for (var key in jsonData.TegList) {
                        var row = tbody.insertRow(tbody.rows.length);
                        var cellId = row.insertCell(row.length);
                        var cellName = row.insertCell(row.length);
                        var cellSize = row.insertCell(row.length);
                        var cellOrientation = row.insertCell(row.length);
                        var cellRoute = row.insertCell(row.length);
                        var cellLocked = row.insertCell(row.length);
                        var cellButton = row.insertCell(row.length);

                        cellId.innerHTML = jsonData.TegList[key].Id;
                        cellName.innerHTML = jsonData.TegList[key].Name;
                        cellSize.innerHTML = jsonData.TegList[key].Size;
                        cellOrientation.innerHTML = jsonData.TegList[key].Orientation;
                        cellRoute.innerHTML = jsonData.TegList[key].Route;

                        if (jsonData.TegList[key].Locked == 1) {
                            cellLocked.innerHTML = "<span class='mdi mdi-lock mr-2' style='color: red;'></span>"
                        } else if (jsonData.TegList[key].Locked == 0) {
                            cellLocked.innerHTML = "<span class='mdi mdi-lock-open mr-2' style='color: green;'></span>"
                        } else {
                            cellLocked.innerHTML = ""
                        }

                        var buttonInfo = document.createElement("button");
                        var buttonEdit = document.createElement("button");
                        var buttonCopy = document.createElement("button");
                        var buttonTrash = document.createElement("button");

                        buttonInfo.type = "button";
                        buttonInfo.setAttribute("class", "btn btn-primary btn-sm");
                        buttonInfo.setAttribute("onclick", "getTegInfo(" + jsonData.TegList[key].Id + ")");
                        buttonInfo.innerHTML = "<span class='mdi mdi-information-outline mr-1'></span>";
                        buttonEdit.type = "button";
                        buttonEdit.setAttribute("class", "btn btn-warning btn-sm");
                        buttonEdit.setAttribute("onclick", "openDivManagePanelChangeFormControl(this)");
                        buttonEdit.innerHTML = "<span class='mdi mdi-pencil mr-1'></span>";
                        buttonTrash.type = "button";
                        buttonTrash.setAttribute("class", "btn btn-danger btn-sm");
                        buttonTrash.setAttribute("onclick", "deleteTeg(" + jsonData.TegList[key].Id + ")");
                        buttonTrash.innerHTML = "<span class='mdi mdi-trash-can mr-1'></span>";

                        cellButton.appendChild(buttonInfo);
                        cellButton.appendChild(buttonEdit);
                        cellButton.appendChild(buttonTrash);
                    }
                } else {
                    alertMsg("Не корректный ответ от сервера");
                }
            } catch (e) {
                alertMsg("Ошибка в структуре ответа от сайта:<br>" + e);
            }
        },
        error: function (request, status, error) {
            alertMsg("Ошибка при обращении к серверу:<br>error:" + error + "<br>status:" + status);
        }
    });
}

function getTegInfo(id) {

    insertSpinner(modalTegInfo_id);
    insertSpinner(modalTegInfo_path);
    insertSpinner(modalTegInfo_name);
    insertSpinner(modalTegInfo_size);
    insertSpinner(modalTegInfo_orientation);
    insertSpinner(modalTegInfo_md5);
    insertSpinner(modalTegInfo_primaryCell);
    insertSpinner(modalTegInfo_creationDate);
    insertSpinner(modalTegInfo_expirationDate);
    insertSpinner(modalTegInfo_routes);
    insertSpinner(modalTegInfo_ui);
    insertSpinner(modalTegInfo_cells);

    modalTegInfoTitle.innerHTML = "Информация по TEG №" + id;

    var formData = new FormData();
    formData.append('queryId', 'getTegInfo');
    formData.append('tegId', id);
    $.ajax({
        url: pathAjax.value,
        type: 'POST',
        data: formData,
        processData: false,
        contentType: false,
        success: function (data) {
            try {
                var jsonData = JSON.parse(data);
                if (typeof jsonData.AjaxError !== "undefined") {
                    $('#modalTegInfo').modal('hide');
                    alertMsg(jsonData.AjaxError);
                } else if (typeof jsonData.TegInfo !== "undefined") {
                    $('#modalTegInfo').modal('show');
                    modalTegInfo_id.innerHTML = jsonData.TegInfo.Id;
                    modalTegInfo_path.innerHTML = jsonData.TegInfo.Path;
                    modalTegInfo_name.innerHTML = jsonData.TegInfo.Name;
                    modalTegInfo_size.innerHTML = jsonData.TegInfo.Size;
                    modalTegInfo_orientation.innerHTML = jsonData.TegInfo.Orientation;
                    modalTegInfo_md5.innerHTML = jsonData.TegInfo.Md5;
                    modalTegInfo_primaryCell.innerHTML = jsonData.TegInfo.PrimaryCell;
                    modalTegInfo_expirationDate.innerHTML = jsonData.TegInfo.ExpirationDate;
                    modalTegInfo_creationDate.innerHTML = jsonData.TegInfo.CreationDate;
                    modalTegInfo_routes.innerHTML = jsonData.TegInfo.Routes;
                    modalTegInfo_ui.innerHTML = jsonData.TegInfo.UI;
                    modalTegInfo_cells.innerHTML = jsonData.TegInfo.Cells;
                } else {
                    $('#modalTegInfo').modal('hide');
                    alertMsg("Не корректный ответ от сервера");
                }
            } catch (e) {
                $('#modalTegInfo').modal('hide');
                alertMsg("Ошибка в структуре ответа от сайта:<br>" + e);
            }
        },
        error: function (request, status, error) {
            $('#modalTegInfo').modal('hide');
            alertMsg("Ошибка при обращении к серверу:<br>error:" + error + "<br>status:" + status);
        }
    });
}

function getTegInfoForChangeFormControl() {
    initalStateManagePanelChangeFormControl();
    if (managePanelChange_formSearchTeg_id.value != "") {
        var formData = new FormData();
        formData.append('queryId', 'getTegInfo');
        formData.append('tegId', managePanelChange_formSearchTeg_id.value);
        $.ajax({
            url: pathAjax.value,
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function (data) {
                try {
                    var jsonData = JSON.parse(data);
                    if (typeof jsonData.AjaxError !== "undefined") {
                        alertMsg(jsonData.AjaxError);
                    } else if (typeof jsonData.TegInfo !== "undefined") {
                        managePanelChange_formControlTeg_id.innerHTML = jsonData.TegInfo.Id;
                        managePanelChange_formControlTeg_path.value = jsonData.TegInfo.Path;
                        managePanelChange_formControlTeg_md5.value = jsonData.TegInfo.Md5;
                        managePanelChange_formControlTeg_sizeX.value = jsonData.TegInfo.SizeX;
                        managePanelChange_formControlTeg_sizeY.value = jsonData.TegInfo.SizeY;

                        managePanelChange_formControlTeg_orientation.value = jsonData.TegInfo.Orientation;
                        $('#managePanelChange_formControlTeg_orientation').selectpicker('refresh');
                        $('#managePanelChange_formControlTeg_orientation').selectpicker('val', jsonData.TegInfo.Orientation);
                        managePanelChange_formControlTeg_locked.value = jsonData.TegInfo.Locked;
                        $('#managePanelChange_formControlTeg_locked').selectpicker('refresh');
                        $('#managePanelChange_formControlTeg_locked').selectpicker('val', jsonData.TegInfo.Locked);

                        selectpickerRefresh("managePanelChange_formControlTeg_primaryCell", "Ячейка ...", jsonData.TegInfo.PrimaryCells, 2, jsonData.TegInfo.PrimaryCellId);
                        selectpickerRefresh("managePanelChange_formControlTeg_routesSelectRoute", "Маршрут ...", jsonData.TegInfo.DistinctRoutes, 2, "");
                        selectpickerRefresh("managePanelChange_formControlTeg_rowTegCells_selectCells", "Тестовые полосы...", jsonData.TegInfo.DistinctCells, 2, "");
                        selectpickerRefresh("managePanelChange_formControlTeg_uiSelectUi", "Запуски...", jsonData.TegInfo.UIDistinct, 2, "");

                        for (var key in jsonData.TegInfo.RoutesInclude) {
                            createInputGroup(managePanelChange_formControlTeg_rowRoutes.children[1].children[0], jsonData.TegInfo.RoutesInclude[key].Name, jsonData.TegInfo.RoutesInclude[key].Id, "managePanelChange_formControlTeg_rowRoutes_row_id" + jsonData.TegInfo.RoutesInclude[key].Id, "updateTegParam('deleteBaseRouteRelation', managePanelChange_formControlTeg_rowRoutes_row_id" + jsonData.TegInfo.RoutesInclude[key].Id + ")");
                        }

                        for (var key in jsonData.TegInfo.CellsInclude) {
                            createRowCellsInTeg(jsonData.TegInfo.CellsInclude[key]);
                        }

                        for (var key in jsonData.TegInfo.UIList) {
                            createInputGroup(managePanelChange_formControlTeg_rowUI.children[1].children[0], jsonData.TegInfo.UIList[key].Name, jsonData.TegInfo.UIList[key].Id, "managePanelChange_formControlTeg_rowUI_row_id" + jsonData.TegInfo.UIList[key].Id, "updateTegParam('deleteTegUITZRelation', managePanelChange_formControlTeg_rowUI_row_id" + jsonData.TegInfo.UIList[key].Id + ")");
                        }


                        managePanelChange_formControlTeg.children[0].disabled = false;
                    } else {
                        alertMsg("Не корректный ответ от сервера");
                    }
                } catch (e) {
                    alertMsg("Ошибка в структуре ответа от сайта:<br>" + e);
                }
            },
            error: function (request, status, error) {
                alertMsg("Ошибка при обращении к серверу:<br>error:" + error + "<br>status:" + status);
            }
        });
    }
}

function getRouteList(div) {
    var formData = new FormData();
    formData.append('queryId', 'getRoute');
    div.innerHTML = "";
    $.ajax({
        url: pathAjax.value,
        type: 'POST',
        data: formData,
        processData: false,
        contentType: false,
        success: function (data) {
            try {
                var jsonData = JSON.parse(data);
                if (typeof jsonData.AjaxError !== "undefined") {
                    alertMsg(jsonData.AjaxError);
                } else if (typeof jsonData.Routes !== "undefined") {
                    for (var key in jsonData.Routes) {
                        createCustomRouteCheckBox(div, jsonData.Routes[key]);
                    }
                } else {
                    alertMsg("Не корректный ответ от сервера");
                }
            } catch (e) {
                alertMsg("Ошибка в структуре ответа от сайта:<br>" + e);
            }
        },
        error: function (request, status, error) {
            alertMsg("Ошибка при обращении к серверу:<br>error:" + error + "<br>status:" + status);
        }
    });
}

function initalStateManagePanelCreateForm() {
    $("#managePanelCreate_form")[0].reset();
    getPrimaryCellForSelectPicker(managePanelCreate_form_primaryCell);
    getRouteList(managePanelCreate_form_divRoute);
}

function initalStateManagePanelChangeForm() {
    getFiltrSearchTeg();
    initalStateManagePanelChangeFormControl();
}

function initalStateManagePanelChangeFormSearch() {
    clearSelectPicker(managePanelChange_formSearchTeg_id);
    clearSelectPicker(managePanelChange_formSearchTeg_technology);
    clearSelectPicker(managePanelChange_formSearchTeg_route);
    clearSelectPicker(managePanelChange_formSearchTeg_ui);
}

function initalStateManagePanelChangeFormControl() {
    managePanelChange_formControlTeg_id.innerHTML = "";
    managePanelChange_formControlTeg_path.value = "";
    managePanelChange_formControlTeg_md5.value = "";
    managePanelChange_formControlTeg_sizeX.value = "";
    managePanelChange_formControlTeg_sizeY.value = "";
    managePanelChange_formControlTeg_orientation.value = "";
    $('#managePanelChange_formControlTeg_orientation').selectpicker('refresh');
    $('#managePanelChange_formControlTeg_orientation').selectpicker('val', "");
    managePanelChange_formControlTeg_locked.value = ""
    $('#managePanelChange_formControlTeg_locked').selectpicker('refresh');
    $('#managePanelChange_formControlTeg_locked').selectpicker('val', "");
    clearSelectPicker(managePanelChange_formControlTeg_primaryCell);

    managePanelChange_formControlTeg_rowRoutes.children[1].children[0].innerHTML = "";
    clearSelectPicker(managePanelChange_formControlTeg_routesSelectRoute);

    //managePanelChange_formControlTeg_rowTegCells.children[1].children[0].innerHTML = "";
    managePanelChange_formControlTeg_tableTegCells.children[1].innerHTML = "";
    clearSelectPicker(managePanelChange_formControlTeg_rowTegCells_selectCells);

    managePanelChange_formControlTeg_rowUI.children[1].children[0].innerHTML = "";
    clearSelectPicker(managePanelChange_formControlTeg_uiSelectUi);

    managePanelChange_formControlTeg.children[0].disabled = true;

}

function initalStateManagePanelCellDistinctInTegForm() {
    divManagePanelCellDistinctInTeg.children[0].children[0].innerHTML = "";
    var formData = new FormData();
    formData.append('queryId', 'getCellDistinctRelationWithTeg');
    formData.append('tegId', managePanelChange_formSearchTeg_id.value);
    $.ajax({
        url: pathAjax.value,
        type: 'POST',
        data: formData,
        processData: false,
        contentType: false,
        success: function (data) {
            try {
                var jsonData = JSON.parse(data);
                if (typeof jsonData.AjaxError !== "undefined") {
                    alertMsg(jsonData.AjaxError);
                } else if (typeof jsonData.CellList !== "undefined") {
                    for (var key in jsonData.CellList) {
                        createInputGroup(divManagePanelCellDistinctInTeg.children[0].children[0], jsonData.CellList[key].Name, jsonData.CellList[key].Id, "divManagePanelCellDistinctInTeg_row_id" + jsonData.CellList[key].Id, "updateTegParam('deleteCell', divManagePanelCellDistinctInTeg_row_id" + jsonData.CellList[key].Id + ")");
                    }
                } else {
                    alertMsg("Не корректный ответ от сервера");
                }
            } catch (e) {
                alertMsg("Ошибка в структуре ответа от сайта:<br>" + e);
            }
        },
        error: function (request, status, error) {
            alertMsg("Ошибка при обращении к серверу:<br>error:" + error + "<br>status:" + status);
        }
    });
}

function openDivManagePanelChangeFormControl(btn) {
    $('#managePanel a[href="#divManagePanelChange"]').tab('show');
    managePanel.scrollIntoView();
    initalStateManagePanelChangeForm();
    var row = btn.parentNode.parentNode;
    getFiltrSearchTeg(row.children[0].innerHTML);
}

function updateTegParam(typeChangeTegParam, el) {
    var formData = new FormData(managePanelCreate_form);
    formData.append('value', el.value);
    formData.append('tegId', managePanelChange_formSearchTeg_id.value);
    switch (typeChangeTegParam) {
        case "updatePath":
            if (el.value != "") {
                formData.append('queryId', 'updateTegPath');
            } else {
                alertMsg("Путь не может быть пустым");
                return false;
            }
            break;
        case "updateMd5":
            if (el.value != "") {
                formData.append('queryId', 'updateTegMd5');
            } else {
                alertMsg("Поле md5 не может быть пустым");
                return false;
            }
            break;
        case "updateSizeX":
            if (el.value == "") {
                alertMsg("Поле sizeX не может быть пустым");
                return false;
            } else if (!isInt_number(el.value) && !isFloat_number(el.value)) {
                alertMsg("Не корректное число размера тега по X");
                return false;
            } else {
                formData.append('queryId', 'updateTegSizeX');
            }
        case "updateSizeY":
            if (el.value == "") {
                alertMsg("Поле sizeY не может быть пустым");
                return false;
            } else if (!isInt_number(el.value) && !isFloat_number(el.value)) {
                alertMsg("Не корректное число размера тега по Y");
                return false;
            } else {
                formData.append('queryId', 'updateTegSizeY');
            }
            break;
        case "updateOrientation":
            if (el.value != "") {
                formData.append('queryId', 'updateTegOrientation');
            } else {
                alertMsg("Значение поля ориентации не может быть пустым");
                return false;
            }
            break;
        case "updateLocked":
            if (el.value != "") {
                formData.append('queryId', 'updateTegLocked');
            } else {
                alertMsg("Значение поля использование не может быть пустым");
                return false;
            }
            break;
        case "updatePrimaryCell":
            if (el.value != "") {
                formData.append('queryId', 'updateTegPrimaryCell');
            } else {
                alertMsg("Значение поля опорной тестовой линейки не может быть пустым");
                return false;
            }
            break;
        case "deleteBaseRouteRelation":
            if (el.value != "") {
                formData.append('queryId', 'deleteTegBaseRouteRelation');
            } else {
                alertMsg("Значение поля маршрута не может быть пустым");
                return false;
            }
            break;
        case "createBaseRouteRelation":
            if (el.value != "") {
                formData.append('queryId', 'createTegBaseRouteRelation');
            } else {
                alertMsg("Значение поля маршрута не может быть пустым");
                return false;
            }
            break;
        case "deleteCellRelation":
            if (el.value != "") {
                formData.append('queryId', 'deleteTegCellRelation');
            } else {
                alertMsg("Значение поля тестовой линейки не может быть пустым");
                return false;
            }
            break;
        case "createCellRelation":
            if (el.value != "") {
                formData.append('queryId', 'createTegCellRelation');
            } else {
                alertMsg("Значение поля тестовой линейки не может быть пустым");
                return false;
            }
            break;
        case "createNewCell":
            if (el.value == "") {
                alertMsg("Имя тестовой линейки не может быть пустым");
                return false;
            } else {
                formData.append('queryId', 'createNewCellAndRelationWithTeg');
            }
            break;
        case "deleteCell":
            formData.append('queryId', 'deleteCell');
            break;
        case "updateMandatoryCell":
            formData.append('queryId', 'updateMandatoryCell');
            if (el.checked) {
                formData.append('Value', 1);
            } else {
                formData.append('Value', 0);
            }
            formData.append('Id', el.value);
            break;
        case "createTegUITZIdRelation":
            if (el.value == "") {
                alertMsg("Запуск не может быть пустым");
                return false;
            } else {
                formData.append('queryId', 'createTegUITZIdRelation');
            }
            break;
        case "deleteTegUITZRelation":
            if (el.value == "") {
                alertMsg("Запуск не может быть пустым");
                return false;
            } else {
                formData.append('queryId', 'deleteTegUITZRelation');
            }
            break;
    }
    $.ajax({
        url: pathAjax.value,
        type: 'POST',
        data: formData,
        processData: false,
        contentType: false,
        success: function (data) {
            try {
                var jsonData = JSON.parse(data);
                if (typeof jsonData.AjaxError !== "undefined") {
                    alertMsg(jsonData.AjaxError);
                } else if (typeof jsonData.Success !== "undefined") {
                    getFiltrSearchTeg(managePanelChange_formSearchTeg_id.value);
                    getTeg();
                    initalStateManagePanelCellDistinctInTegForm();
                } else {
                    alertMsg("Не корректный ответ от сервера");
                }
            } catch (e) {
                alertMsg("Ошибка в структуре ответа от сайта:<br>" + e);
            }
        },
        error: function (request, status, error) {
            alertMsg("Ошибка при обращении к серверу:<br>error:" + error + "<br>status:" + status);
        }
    });
}

function uploadCellIniForFormCreateNewTeg() {
    managePanelCreate_form_cellsTable.children[1].innerHTML = "";
    var formData = new FormData(managePanelCreate_form);
    if (formData.get('path') == "") {
        alertMsg("Необходимо сначала указать путь к тегу!");
        return false;
    }
    formData.append('queryId', 'uploadCellIni');
    $.ajax({
        url: pathAjax.value,
        type: 'POST',
        data: formData,
        processData: false,
        contentType: false,
        success: function (data) {
            try {
                var jsonData = JSON.parse(data);
                if (typeof jsonData.AjaxError !== "undefined") {
                    alertMsg(jsonData.AjaxError);
                } else if (typeof jsonData.Content !== "undefined") {
                    managePanelCreate_form_md5.value = jsonData.Md5;
                    var tbody = managePanelCreate_form_cellsTable.children[1];
                    for (var key in jsonData.Content) {
                        var row = tbody.insertRow(tbody.rows.length);
                        var cellId = row.insertCell(row.length);
                        var cellName = row.insertCell(row.length);
                        var cellRoute = row.insertCell(row.length);
                        var cellTeg = row.insertCell(row.length);

                        if (jsonData.Content[key].Id == "") {
                            var butCreateCell = document.createElement("button");
                            butCreateCell.type = "button";
                            butCreateCell.setAttribute("class", "btn btn-primary");
                            butCreateCell.setAttribute("onclick", "createNewCellForFormCreateTeg(this)");
                            butCreateCell.innerHTML = "Создать ячейку";
                            cellId.appendChild(butCreateCell);
                            cellRoute.innerHTML = "";
                            cellTeg.innerHTML = "";
                        } else {
                            var checkBoxIncludeCell = document.createElement("input");
                            checkBoxIncludeCell.type = "checkbox";
                            checkBoxIncludeCell.value = jsonData.Content[key].Id;
                            checkBoxIncludeCell.name = "tegCellId[]";
                            cellId.appendChild(checkBoxIncludeCell);
                            cellRoute.innerHTML = jsonData.Content[key].RouteList;
                            cellTeg.innerHTML = jsonData.Content[key].TegList;
                        }
                        cellName.innerHTML = jsonData.Content[key].Name;
                    }
                    managePanelCreate_form_cellsTable.hidden = false;
                } else {
                    alertMsg("Не корректный ответ от сервера");
                }
            } catch (e) {
                alertMsg("Ошибка в структуре ответа от сайта:<br>" + e);
            }
        },
        error: function (request, status, error) {
            alertMsg("Ошибка при обращении к серверу:<br>error:" + error + "<br>status:" + status);
        }
    });
}

function createNewCellForFormCreateTeg(btn) {
    var row = btn.parentNode.parentNode;
    var name = row.children[1].innerHTML;
    var formData = new FormData();
    formData.append('name', name);
    formData.append('queryId', 'createCell');

    $.ajax({
        url: pathAjax.value,
        type: 'POST',
        data: formData,
        processData: false,
        contentType: false,
        success: function (data) {
            try {
                var jsonData = JSON.parse(data);
                if (typeof jsonData.AjaxError !== "undefined") {
                    alertMsg(jsonData.AjaxError);
                } else if (typeof jsonData.Success !== "undefined") {
                    var cellButt = row.children[0];
                    cellButt.innerHTML = "";

                    var checkBoxIncludeCell = document.createElement("input");
                    checkBoxIncludeCell.type = "checkbox";
                    checkBoxIncludeCell.checked = true;
                    checkBoxIncludeCell.value = jsonData.Success;
                    checkBoxIncludeCell.name = "tegCellId[]";
                    cellButt.appendChild(checkBoxIncludeCell);

                    getPrimaryCellForSelectPicker(managePanelCreate_form_primaryCell);
                } else {
                    alertMsg("Не корректный ответ от сервера");
                }
            } catch (e) {
                alertMsg("Ошибка в структуре ответа от сайта:<br>" + e);
            }
        },
        error: function (request, status, error) {
            alertMsg("Ошибка при обращении к серверу:<br>error:" + error + "<br>status:" + status);
        }
    });
}

function eventClickManagePanelCreateFormCellsTable(event) {
    let target = event.target;
    if (target.tagName == "TD") {
        var row = target.parentNode;
        var cell0 = row.children[0];
        if (cell0.children[0].tagName == "INPUT") {
            var checkbox = cell0.children[0];
            if (checkbox.checked) {
                checkbox.checked = false;
            } else {
                checkbox.checked = true;
            }
        }
    }
}

function createRowCellsInTeg(cellInfo) {
    var tbody = managePanelChange_formControlTeg_tableTegCells.children[1];
    var row = tbody.insertRow(tbody.rows.length);
    var cellName = row.insertCell(row.length);
    var cellRoute = row.insertCell(row.length);
    var cellMandatory = row.insertCell(row.length);
    var cellTeg = row.insertCell(row.length);
    var cellDeleteR = row.insertCell(row.length);

    cellName.innerHTML = cellInfo.Name;
    cellTeg.innerHTML = cellInfo.TegList;

    var butD = document.createElement("button");
    butD.type = "button";
    butD.setAttribute("class", "btn btn-danger btn-sm");
    butD.innerHTML = "<span class='mdi mr-1 mdi-trash-can-outline'></span>";
    butD.value = cellInfo.Id;
    butD.setAttribute("onclick", "updateTegParam('deleteCellRelation',this)");
    cellDeleteR.appendChild(butD);

    if (cellInfo.RouteList != "") {

        cellRoute.innerHTML = cellInfo.RouteList[0].Name;

        var checkboxMandatory = document.createElement("input");
        checkboxMandatory.type = "checkbox";
        checkboxMandatory.value = cellInfo.RouteList[0].Id;
        checkboxMandatory.setAttribute("onchange", "updateTegParam('updateMandatoryCell',this)");

        if (cellInfo.RouteList[0].Mandatory == 1) {
            checkboxMandatory.checked = true;
        }
        cellMandatory.appendChild(checkboxMandatory);

        if (cellInfo.RouteList.length > 1) {
            cellName.setAttribute("rowspan", cellInfo.RouteList.length);
            cellTeg.setAttribute("rowspan", cellInfo.RouteList.length);
            cellDeleteR.setAttribute("rowspan", cellInfo.RouteList.length);
            for (var i = 1; i < cellInfo.RouteList.length; i++) {
                var row = tbody.insertRow(tbody.rows.length);
                var cellRoute = row.insertCell(row.length);
                cellRoute.innerHTML = cellInfo.RouteList[i].Name;

                var cellMandatory = row.insertCell(row.length);
                var checkboxMandatory = document.createElement("input");
                checkboxMandatory.type = "checkbox";
                checkboxMandatory.value = cellInfo.RouteList[i].Id;
                checkboxMandatory.setAttribute("onchange", "updateTegParam('updateMandatoryCell',this)");
                if (cellInfo.RouteList[i].Mandatory == 1) {
                    checkboxMandatory.checked = true;
                }
                cellMandatory.appendChild(checkboxMandatory);
            }
        }
    }
}