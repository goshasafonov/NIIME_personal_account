<?php

ini_set('error_reporting', 0);
ini_set('display_errors', 0);

$msg = array();
define('APP', true);
require_once ("./../config.php");
require_once ("./../login.php");
if (isset($msg["AjaxError"])) {
    echo json_encode($msg);
    exit();
}

$queryId = $_POST['queryId'];
switch ($queryId) {
    case "createCell":
        $query = "INSERT INTO `TEG::Cell` SET `Name`='" . $_POST['name'] . "'";
        $result = $mysqli->query($query);
        if ($result) {
            $msg["Success"] = $mysqli->insert_id;
        } else {
            $msg["AjaxError"] = "Ошибка в запросе:<br>" . $mysqli->error . "<br>$query";
        }
        break;
    case "createNewCellAndRelationWithTeg":
        //1.Создать новую ячейку        

        $query = ""
                . "INSERT INTO"
                . " `TEG::Cell` "
                . "SET"
                . " `TEG::Cell`.Name = '" . $_POST['value'] . "' ";
        $result = $mysqli->query($query);
        if ($result) {
            $tegCellId = $mysqli->insert_id;
        } else {
            $msg["AjaxError"] = "Ошибка в запросе:<br>" . $mysqli->error . "<br>$query";
            break;
        }

        //2.Получить все маршруты тега и привезать их к новой ячейке
        //маршруты
        $query = ""
                . " SELECT"
                . "  `TEG::Cell_BaseRoute_R`.BaseRouteId"
                . " FROM "
                . "  `TEG::Cell_TEG_R`"
                . "  LEFT JOIN `TEG::Cell_BaseRoute_R` ON `TEG::Cell_BaseRoute_R`.CellId = `TEG::Cell_TEG_R`.CellId "
                . " WHERE"
                . "  `TEG::Cell_TEG_R`.TegId = " . $_POST['tegId'] . " "
                . " GROUP BY `BaseRouteId` "
                . " HAVING COUNT(`BaseRouteId`) = ("
                . "  SELECT"
                . "   COUNT(`TEG::Cell_TEG_R`.Id)"
                . "  FROM"
                . "   `TEG::Cell_TEG_R` "
                . "  WHERE"
                . "   `TEG::Cell_TEG_R`.TegId = " . $_POST['tegId'] . " "
                . " )";
        $resultBR = $mysqli->query($query);
        $msg[] = "$query";
        if ($resultBR) {
            while ($rowBR = $resultBR->fetch_assoc()) {
                $query = ""
                        . "INSERT INTO"
                        . " `TEG::Cell_BaseRoute_R` "
                        . "SET"
                        . " `CellId`=" . $tegCellId . ", "
                        . " `BaseRouteId`=" . $rowBR['BaseRouteId'];
                $result = $mysqli->query($query);
                if (!$result) {
                    $msg["AjaxError"] = "Ошибка в запросе:<br>" . $mysqli->error . "<br>$query";
                    break;
                }
            }
        } else {
            $msg["AjaxError"] = "Ошибка в запросе:<br>" . $mysqli->error . "<br>$query";
        }
        //3.Добавить связь с тегом
        $query = ""
                . "INSERT INTO"
                . " `TEG::Cell_TEG_R` "
                . "SET"
                . " `TegId` = " . $_POST['tegId'] . ", "
                . " `CellId` = " . $tegCellId;
        $result = $mysqli->query($query);
        if (!$result) {
            $msg["AjaxError"] = "Ошибка в запросе:<br>" . $mysqli->error . "<br>$query";
            break;
        } else {
            $msg["Success"] = "true";
        }
        break;
    case "createTeg":
        $query = ""
                . "INSERT INTO"
                . " `TEG` "
                . "SET"
                . " Path = '" . $_POST['path'] . "', "
                . " Orientation = '" . $_POST['orientation'] . "', "
                . " SizeX = " . $_POST['sizeX'] . ", "
                . " SizeY = " . $_POST['sizeY'] . ", "
                . " Md5 = '" . $_POST['md5'] . "', "
                . " PrimaryCellId = " . $_POST['primaryCell'];
        $result = $mysqli->query($query);
        if ($result) {
            $tegId = $mysqli->insert_id;
            $msg["Success"] = $tegId;
            if (isset($_POST["tegCellId"])) {
                $tegCellId = $_POST["tegCellId"];
                $routeId = $_POST["route"];
                foreach ($tegCellId as $key => $value) {
                    //Добавление связи ячейки и тега
                    $query = "INSERT INTO"
                            . " `TEG::Cell_TEG_R` "
                            . "SET"
                            . " `CellId` = $value,"
                            . " `TegId` = $tegId";
                    $result = $mysqli->query($query);
                    if (!$result) {
                        $msg["AjaxError"] = "Ошибка в запросе:<br>" . $mysqli->error . "<br>$query";
                        break;
                    }
                    //проверка существования связи ячейка - маршрут
                    foreach ($routeId as $keyRoute => $valueRoute) {
                        $query = ""
                                . "SELECT"
                                . " `TEG::Cell_BaseRoute_R`.Id "
                                . "FROM"
                                . " `TEG::Cell_BaseRoute_R` "
                                . "WHERE"
                                . " `TEG::Cell_BaseRoute_R`.CellId = " . $value . " AND"
                                . " `TEG::Cell_BaseRoute_R`.BaseRouteId = " . $valueRoute;
                        $result = $mysqli->query($query);
                        if (!$result) {
                            $msg["AjaxError"] = "Ошибка в запросе:<br>" . $mysqli->error . "<br>$query";
                            break;
                        } else {
                            if ($result->num_rows == 0) {
                                $query = ""
                                        . "INSERT INTO"
                                        . " `TEG::Cell_BaseRoute_R` "
                                        . "SET"
                                        . " `TEG::Cell_BaseRoute_R`.CellId = " . $value . ","
                                        . " `TEG::Cell_BaseRoute_R`.BaseRouteId = " . $valueRoute;
                                $result = $mysqli->query($query);
                                if (!$result) {
                                    $msg["AjaxError"] = "Ошибка в запросе:<br>" . $mysqli->error . "<br>$query";
                                    break;
                                }
                            }
                        }
                    }
                }
            }
        } else {
            $msg["AjaxError"] = "Ошибка в запросе:<br>" . $mysqli->error . "<br>$query";
        }
        break;
    case "createTegBaseRouteRelation":
        //1.Получить список всех ячеек
        //2.Добавить ко всем ячейкам связи с новым маршрутом, если этой связи нет

        $query = ""
                . "SELECT"
                . " `TEG::Cell_TEG_R`.CellId "
                . "FROM"
                . " `TEG::Cell_TEG_R` "
                . "WHERE"
                . " `TEG::Cell_TEG_R`.TegId = " . $_POST["tegId"];
        $result = $mysqli->query($query);
        if ($result) {
            while ($row = $result->fetch_assoc()) {
                $query = ""
                        . "SELECT"
                        . " `TEG::Cell_BaseRoute_R`.Id "
                        . "FROM"
                        . " `TEG::Cell_BaseRoute_R` "
                        . "WHERE"
                        . " `TEG::Cell_BaseRoute_R`.CellId = " . $row['CellId'] . " AND"
                        . " `TEG::Cell_BaseRoute_R`.BaseRouteId = " . $_POST["value"];
                $resultR = $mysqli->query($query);
                if (!$resultR) {
                    $msg["AjaxError"] = "Ошибка в запросе:<br>" . $mysqli->error . "<br>$query";
                    break;
                } else {
                    if ($resultR->num_rows == 0) {
                        $query = ""
                                . "INSERT INTO"
                                . " `TEG::Cell_BaseRoute_R` "
                                . "SET"
                                . " `TEG::Cell_BaseRoute_R`.CellId = " . $row['CellId'] . ","
                                . " `TEG::Cell_BaseRoute_R`.BaseRouteId = " . $_POST["value"];
                        $resultR = $mysqli->query($query);
                        if (!$resultR) {
                            $msg["AjaxError"] = "Ошибка в запросе:<br>" . $mysqli->error . "<br>$query";
                            break;
                        }
                    }
                }
            }
            $msg["Success"] = "true";
        } else {
            $msg["AjaxError"] = "Ошибка в запросе:<br>" . $mysqli->error . "<br>$query";
            break;
        }
        break;
    case "createTegCellRelation":
        //1. Получить список маршрутов
        //2. Дополнить маршруты на тестовую сборку
        $query = ""
                . " SELECT"
                . "  `TEG::Cell_BaseRoute_R`.BaseRouteId"
                . " FROM "
                . "  `TEG::Cell_TEG_R`"
                . "  LEFT JOIN `TEG::Cell_BaseRoute_R` ON `TEG::Cell_BaseRoute_R`.CellId = `TEG::Cell_TEG_R`.CellId "
                . " WHERE"
                . "  `TEG::Cell_TEG_R`.TegId = " . $_POST['tegId'] . " "
                . " GROUP BY `BaseRouteId` "
                . " HAVING COUNT(`BaseRouteId`) = ("
                . "  SELECT"
                . "   COUNT(`TEG::Cell_TEG_R`.Id)"
                . "  FROM"
                . "   `TEG::Cell_TEG_R` "
                . "  WHERE"
                . "   `TEG::Cell_TEG_R`.TegId = " . $_POST['tegId'] . " "
                . " )";
        $resultBR = $mysqli->query($query);
        $msg[] = "$query";
        if ($resultBR) {
            while ($rowBR = $resultBR->fetch_assoc()) {
                $query = ""
                        . "SELECT"
                        . " `TEG::Cell_BaseRoute_R`.Id "
                        . "FROM"
                        . " `TEG::Cell_BaseRoute_R` "
                        . "WHERE"
                        . " `TEG::Cell_BaseRoute_R`.CellId = " . $_POST["value"] . " AND"
                        . " `TEG::Cell_BaseRoute_R`.BaseRouteId = " . $rowBR['BaseRouteId'];
                $resultR = $mysqli->query($query);
                if (!$resultR) {
                    $msg["AjaxError"] = "Ошибка в запросе:<br>" . $mysqli->error . "<br>$query";
                    break;
                } else {
                    if ($resultR->num_rows == 0) {
                        $query = ""
                                . "INSERT INTO"
                                . " `TEG::Cell_BaseRoute_R` "
                                . "SET"
                                . " `CellId`=" . $_POST["value"] . ", "
                                . " `BaseRouteId`=" . $rowBR['BaseRouteId'];
                        $result = $mysqli->query($query);
                        if (!$result) {
                            $msg["AjaxError"] = "Ошибка в запросе:<br>" . $mysqli->error . "<br>$query";
                            break;
                        }
                    }
                }
            }
        } else {
            $msg["AjaxError"] = "Ошибка в запросе:<br>" . $mysqli->error . "<br>$query";
        }
        //3.Добавить связь с тегом
        $query = ""
                . "INSERT INTO"
                . " `TEG::Cell_TEG_R` "
                . "SET"
                . " `TegId` = " . $_POST['tegId'] . ", "
                . " `CellId` = " . $_POST["value"];
        $result = $mysqli->query($query);
        if (!$result) {
            $msg["AjaxError"] = "Ошибка в запросе:<br>" . $mysqli->error . "<br>$query";
            break;
        } else {
            $msg["Success"] = "true";
        }

        break;
    case "createTegUITZIdRelation":
        $query = ""
                . "INSERT INTO"
                . " `TEG_UI::TZ_R` "
                . "SET"
                . " `TEGId` = " . $_POST['tegId'] . ", "
                . " `UITZId` =" . $_POST['value'] . " ";
        $result = $mysqli->query($query);
        if ($result) {
            $msg["Success"] = $tegId;            
        } else {
            $msg["AjaxError"] = "Ошибка в запросе:<br>" . $mysqli->error . "<br>$query";
        }
        break;
    case "deleteCell":
        $query = ""
                . "DELETE FROM"
                . " `TEG::Cell` "
                . "WHERE"
                . " `Id` = " . $_POST["value"];
        $result = $mysqli->query($query);
        if ($result) {
            $msg["Success"] = "true";
        } else {
            $msg["AjaxError"] = "Ошибка в запросе:<br>" . $mysqli->error . "<br>$query";
        }
        break;
    case "deleteTeg":
        $query = ""
                . "SELECT"
                . " `TEG::Cell_TEG_R`.CellId "
                . "FROM"
                . " `TEG::Cell_TEG_R` "
                . "WHERE"
                . " `TEG::Cell_TEG_R`.TegId = " . $_POST["tegId"];
        $result = $mysqli->query($query);

        if ($result) {
            $query = ""
                    . "DELETE FROM"
                    . " `TEG` "
                    . "WHERE"
                    . " `Id` = " . $_POST["tegId"];
            $resultD = $mysqli->query($query);
            if (!$resultD) {
                $msg["AjaxError"] = "Ошибка в запросе:<br>" . $mysqli->error . "<br>$query";
                break;
            }

            while ($row = $result->fetch_assoc()) {
                $query = ""
                        . "SELECT"
                        . " COUNT(Id) as CountId "
                        . "FROM"
                        . " `TEG::Cell_TEG_R` "
                        . "WHERE"
                        . " `TEG::Cell_TEG_R`.CellId =" . $row["CellId"];
                $resultC = $mysqli->query($query);
                if ($resultC) {
                    $rowc = $resultC->fetch_assoc();
                    if ($rowc["CountId"] == 0) {
                        $query = ""
                                . "SELECT"
                                . " COUNT(PrimaryCellId) as CountId "
                                . "FROM"
                                . " `TEG` "
                                . "WHERE"
                                . " `TEG`.PrimaryCellId =" . $row["CellId"];
                        $resultC = $mysqli->query($query);
                        if ($resultC) {
                            $rowc = $resultC->fetch_assoc();
                            if ($rowc["CountId"] == 0) {
                                $query = ""
                                        . "DELETE FROM"
                                        . " `TEG::Cell` "
                                        . "WHERE"
                                        . " `Id` = " . $row["CellId"];
                                $resultD = $mysqli->query($query);
                                if (!$resultD) {
                                    $msg["AjaxError"] = "Ошибка в запросе:<br>" . $mysqli->error . "<br>$query";
                                    break;
                                }
                            }
                        } else {
                            $msg["AjaxError"] = "Ошибка в запросе:<br>" . $mysqli->error . "<br>$query";
                            break;
                        }
                    }
                } else {
                    $msg["AjaxError"] = "Ошибка в запросе:<br>" . $mysqli->error . "<br>$query";
                    break;
                }
            }
        } else {
            $msg["AjaxError"] = "Ошибка в запросе:<br>" . $mysqli->error . "<br>$query";
        }
        $msg["Success"] = "true";
        break;
    case "deleteTegBaseRouteRelation":
        //1. Получить список всех тегов с похожими ячейками
        $query = ""
                . "SELECT"
                . " `TEG::Cell_TEG_R`.CellId "
                . "FROM"
                . " `TEG::Cell_TEG_R` "
                . "WHERE"
                . " `TEG::Cell_TEG_R`.TegId = " . $_POST["tegId"];
        $result = $mysqli->query($query);
        if ($result) {
            while ($row = $result->fetch_assoc()) {
                //2. Проверить используется ли эта ячейка в другом теге с данным маршрутом
                $flagCellDelete = true;
                $queryTeg = ""
                        . "SELECT"
                        . " `TEG::Cell_TEG_R`.TegId "
                        . "FROM"
                        . " `TEG::Cell_TEG_R` "
                        . "WHERE"
                        . " `TEG::Cell_TEG_R`.TegId != " . $_POST["tegId"] . " AND"
                        . " `TEG::Cell_TEG_R`.CellId =" . $row['CellId'];

                $resultTeg = $mysqli->query($queryTeg);
                if ($resultTeg) {
                    while ($rowTeg = $resultTeg->fetch_assoc()) {
                        $queryBR = ""
                                . " SELECT"
                                . "  `TEG::Cell_BaseRoute_R`.BaseRouteId"
                                . " FROM "
                                . "  `TEG::Cell_TEG_R`"
                                . "  LEFT JOIN `TEG::Cell_BaseRoute_R` ON `TEG::Cell_BaseRoute_R`.CellId = `TEG::Cell_TEG_R`.CellId "
                                . " WHERE"
                                . "  `TEG::Cell_TEG_R`.TegId = " . $rowTeg["TegId"] . " AND "
                                . "  `TEG::Cell_BaseRoute_R`.BaseRouteId = " . $_POST['value'] . " "
                                . " GROUP BY `BaseRouteId` "
                                . " HAVING COUNT(`BaseRouteId`) = ("
                                . "  SELECT"
                                . "   COUNT(`TEG::Cell_TEG_R`.Id)"
                                . "  FROM"
                                . "   `TEG::Cell_TEG_R` "
                                . "  WHERE"
                                . "   `TEG::Cell_TEG_R`.TegId = " . $rowTeg["TegId"] . " "
                                . " )";
                        $resultBR = $mysqli->query($queryBR);
                        if ($resultBR) {
                            if ($resultBR->num_rows > 0) {
                                $flagCellDelete = false;
                            }
                        } else {
                            $msg["AjaxError"] = "Ошибка в запросе:<br>" . $mysqli->error . "<br>$queryBR";
                            break;
                        }
                    }
                } else {
                    $msg["AjaxError"] = "Ошибка в запросе:<br>" . $mysqli->error . "<br>$queryTeg";
                    break;
                }
                //3. Если не используется, то можно удалить связь ячейки и маршрута
                if ($flagCellDelete) {
                    $query = ""
                            . "DELETE FROM"
                            . " `TEG::Cell_BaseRoute_R` "
                            . "WHERE"
                            . " `TEG::Cell_BaseRoute_R`.CellId = " . $row['CellId'] . " AND "
                            . " `TEG::Cell_BaseRoute_R`.BaseRouteId = " . $_POST["value"];
                    $resultD = $mysqli->query($query);
                    if (!$resultD) {
                        $msg["AjaxError"] = "Ошибка в запросе:<br>" . $mysqli->error . "<br>$query";
                        break;
                    }
                }
            }
            $msg["Success"] = "true";
        } else {
            $msg["AjaxError"] = "Ошибка в запросе:<br>" . $mysqli->error . "<br>$query";
            break;
        }






        /*
          $query = ""
          . "DELETE FROM"
          . " `Teg_BaseRoute_R` "
          . "WHERE"
          . " `TegId` = " . $_POST["tegId"] . " AND "
          . " `BaseRouteId` = " . $_POST["value"];
          $result = $mysqli->query($query);
          if ($result) {
          $msg["Success"] = "true";
          } else {
          $msg["AjaxError"] = "Ошибка в запросе:<br>" . $mysqli->error . "<br>$query";
          } */
        break;
    case "deleteTegCellRelation":

        $query = ""
                . "DELETE FROM"
                . " `TEG::Cell_TEG_R` "
                . "WHERE"
                . " `TegId` = " . $_POST["tegId"] . " AND "
                . " `CellId` = " . $_POST["value"];
        $result = $mysqli->query($query);
        if (!$result) {
            $msg["AjaxError"] = "Ошибка в запросе:<br>" . $mysqli->error . "<br>$query";
            break;
        }

        $query = ""
                . "SELECT"
                . " COUNT(Id) as CountId "
                . "FROM"
                . " `TEG::Cell_TEG_R` "
                . "WHERE"
                . " `TEG::Cell_TEG_R`.CellId =" . $_POST["value"];
        $result = $mysqli->query($query);
        if ($result) {
            $row = $result->fetch_assoc();
            if ($row["CountId"] == 0) {
                $query = ""
                        . "SELECT"
                        . " COUNT(PrimaryCellId) as CountId "
                        . "FROM"
                        . " `TEG` "
                        . "WHERE"
                        . " `TEG`.PrimaryCellId =" . $_POST["value"];
                $result = $mysqli->query($query);
                if ($result) {
                    $row = $result->fetch_assoc();
                    if ($row["CountId"] == 0) {
                        $query = ""
                                . "DELETE FROM"
                                . " `TEG::Cell` "
                                . "WHERE"
                                . " `Id` = " . $_POST["value"];
                        $result = $mysqli->query($query);
                        if ($result) {
                            $msg["Success"] = "true";
                        } else {
                            $msg["AjaxError"] = "Ошибка в запросе:<br>" . $mysqli->error . "<br>$query";
                            break;
                        }
                    } else {
                        $msg["Success"] = "true";
                    }
                } else {
                    $msg["AjaxError"] = "Ошибка в запросе:<br>" . $mysqli->error . "<br>$query";
                    break;
                }
            } else {
                $msg["Success"] = "true";
            }
        } else {
            $msg["AjaxError"] = "Ошибка в запросе:<br>" . $mysqli->error . "<br>$query";
            break;
        }
        break;
    case "deleteTegUITZRelation": 
        $query = ""
                . "DELETE FROM"
                . " `TEG_UI::TZ_R` "
                . "WHERE"
                . " `TEGId` = " . $_POST['tegId'] . " AND "
                . " `UITZId` =" . $_POST['value'] . " ";
        $result = $mysqli->query($query);
        if ($result) {
            $msg["Success"] = $tegId;            
        } else {
            $msg["AjaxError"] = "Ошибка в запросе:<br>" . $mysqli->error . "<br>$query";
        }
        break;
    case "getCellDistinctRelationWithTeg":
        $query = ""
                . "SELECT"
                . " `TEG::Cell`.Id,"
                . " `TEG::Cell`.Name "
                . "FROM"
                . " `TEG::Cell` "
                . " LEFT JOIN `TEG` ON `TEG`.PrimaryCellId = `TEG::Cell`.Id "
                . "WHERE"
                . " `TEG::Cell`.Id IN ( "
                . "  SELECT"
                . "   `TEG::Cell`.Id "
                . "  FROM"
                . "   `TEG::Cell` "
                . "   LEFT JOIN `TEG::Cell_TEG_R` ON `TEG::Cell_TEG_R`.CellId = `TEG::Cell`.Id "
                . "  WHERE"
                . "   `TEG::Cell_TEG_R`.CellId IS NULL) AND"
                . " `TEG`.Id IS NULL ";
        $result = $mysqli->query($query);
        //$msg["AjaxError"] = $query;
        if ($result) {
            $msg["CellList"] = array();
            $cells = array();
            while ($row = $result->fetch_assoc()) {
                $cells[] = $row;
            }
            $msg["CellList"] = $cells;
        } else {
            $msg["AjaxError"] = "Ошибка в запросе:<br>" . $mysqli->error . "<br>$query";
        }
        break;
    case "getFiltrSearchTeg":
        $msg["Id"] = $_POST["id"];

        $msg["TegId"] = "";
        $tegs = array();
        //TegId
        $query = ""
                . "SELECT"
                . " `TEG`.Id,"
                . " `TEG`.Path "
                . "FROM"
                . " `TEG` ";
        $result = $mysqli->query($query);
        if ($result) {
            $msg["Tegs"] = array();
            while ($row = $result->fetch_assoc()) {
                $name = end(explode("/", $row["Path"]));
                $row["Name"] = $row["Id"] . " - " . $name;
                $tegs[$row["Id"]] = $row["Name"];
            }
        } else {
            $msg["AjaxError"] = "Ошибка в запросе:<br>" . $mysqli->error . "<br>$query";
        }
        $msg["Tegs"] = $tegs;
        break;
    case "getPrimaryCellsTeg":
        $msg["CellId"] = $_POST["cellId"];
        $query = ""
                . "SELECT"
                . " `TEG::Cell`.Id,"
                . " `TEG::Cell`.Name "
                . "FROM"
                . " `TEG::Cell` ";
        $result = $mysqli->query($query);
        if ($result) {
            $msg["Cells"] = array();
            while ($row = $result->fetch_assoc()) {
                $msg["Cells"][$row["Id"]] = $row["Name"];
            }
        } else {
            $msg["AjaxError"] = "Ошибка в запросе:<br>" . $mysqli->error . "<br>$query";
        }
        break;
    case "getTegInfo":
        $query = ""
                . "SELECT"
                . " `TEG`.Id,"
                . " `TEG`.Path,"
                . " CONCAT(`TEG`.SizeX, 'x', `TEG`.SizeY) as Size,"
                . " `TEG`.Md5, "
                . " `TEG`.Orientation,"
                . " `TEG::Cell`.Name as PrimaryCell,"
                . " `TEG`.PrimaryCellId,"
                . " `TEG`.SizeX,"
                . " `TEG`.SizeY,"
                . " `TEG`.CreationDate,"
                . " `TEG`.ExpirationDate "
                . "FROM"
                . " `TEG`"
                . " LEFT JOIN `TEG::Cell` ON `TEG::Cell`.Id = `TEG`.PrimaryCellId "
                . "WHERE"
                . " `TEG`.Id = " . $_POST["tegId"];
        $result = $mysqli->query($query);
        if ($result) {
            $row = $result->fetch_assoc();
            $row["Name"] = end(explode("/", $row["Path"]));
            if ($row["ExpirationDate"] != NULL) {
                $row["Locked"] = 1;
            } else {
                $row["Locked"] = 0;
            }
            //маршруты
            $queryBR = ""
                    . "SELECT"
                    . " `BaseRoute`.Id,"
                    . " `BaseRoute`.Name,"
                    . " `BaseRoute`.Revision "
                    . "FROM"
                    . " `BaseRoute` "
                    . "WHERE"
                    . " `BaseRoute`.Id IN ("
                    . " SELECT"
                    . "  `TEG::Cell_BaseRoute_R`.BaseRouteId"
                    . " FROM "
                    . "  `TEG::Cell_TEG_R`"
                    . "  LEFT JOIN `TEG::Cell_BaseRoute_R` ON `TEG::Cell_BaseRoute_R`.CellId = `TEG::Cell_TEG_R`.CellId "
                    . " WHERE"
                    . "  `TEG::Cell_TEG_R`.TegId = " . $row["Id"] . " "
                    . " GROUP BY `BaseRouteId` "
                    . " HAVING COUNT(`BaseRouteId`) = ("
                    . "  SELECT"
                    . "   COUNT(`TEG::Cell_TEG_R`.Id)"
                    . "  FROM"
                    . "   `TEG::Cell_TEG_R` "
                    . "  WHERE"
                    . "   `TEG::Cell_TEG_R`.TegId = " . $row["Id"] . " "
                    . " )"
                    . ") "
                    . "ORDER BY Name";
            $resultBR = $mysqli->query($queryBR);
            if ($resultBR) {
                $route = array();
                $routeInclude = array();
                while ($rowBR = $resultBR->fetch_assoc()) {
                    $routeI = array();
                    $routeI["Id"] = $rowBR["Id"];
                    $routeI["Name"] = $rowBR["Name"] . " rev- " . $rowBR["Revision"];
                    $routeInclude[] = $routeI;

                    $route[] = $rowBR["Name"] . " <small>rev- " . $rowBR["Revision"] . "</small>";
                }
                $row["Routes"] = implode("<br>", $route);
                $row["RoutesInclude"] = $routeInclude;
            } else {
                $msg["AjaxError"] = "Ошибка в запросе:<br>" . $mysqli->error . "<br>$queryBR";
            }
            //список неиспользуемых маршрутов
            if ($row["Routes"] != "") {
                $queryBR = ""
                        . "SELECT DISTINCT"
                        . " `BaseRoute`.Id,"
                        . " `BaseRoute`.Name, "
                        . " `BaseRoute`.Revision "
                        . "FROM"
                        . " `BaseRoute` "
                        . "WHERE"
                        . " `BaseRoute`.Id NOT IN ("
                        . " SELECT"
                        . "  `TEG::Cell_BaseRoute_R`.BaseRouteId"
                        . " FROM "
                        . "  `TEG::Cell_TEG_R`"
                        . "  LEFT JOIN `TEG::Cell_BaseRoute_R` ON `TEG::Cell_BaseRoute_R`.CellId = `TEG::Cell_TEG_R`.CellId "
                        . " WHERE"
                        . "  `TEG::Cell_TEG_R`.TegId = " . $row["Id"] . " "
                        . " GROUP BY `BaseRouteId` "
                        . " HAVING COUNT(`BaseRouteId`) = ("
                        . "  SELECT"
                        . "   COUNT(`TEG::Cell_TEG_R`.Id)"
                        . "  FROM"
                        . "   `TEG::Cell_TEG_R` "
                        . "  WHERE"
                        . "   `TEG::Cell_TEG_R`.TegId = " . $row["Id"] . " "
                        . " )"
                        . ") "
                        . "ORDER BY `Name`, `Revision`";
            } else {
                $queryBR = ""
                        . "SELECT"
                        . " `BaseRoute`.Id,"
                        . " `BaseRoute`.Name, "
                        . " `BaseRoute`.Revision "
                        . "FROM"
                        . " `BaseRoute` "
                        . "ORDER BY `Name`, `Revision`";
            }
            $resultBR = $mysqli->query($queryBR);
            if ($resultBR) {
                $routes = array();
                while ($rowBR = $resultBR->fetch_assoc()) {
                    $route = array();
                    $route["Id"] = $rowBR["Id"];
                    $route["Name"] = $rowBR["Name"] . " rev- " . $rowBR["Revision"];
                    $routes[] = $route;
                }
                $row["DistinctRoutes"] = $routes;
            } else {
                $msg["AjaxError"] = "Ошибка в запросе:<br>" . $mysqli->error . "<br>$queryBR";
            }
            //запуски
            $row["UI"] = "В разработке.";

            $queryUi = ""
                    . "SELECT"
                    . " CONCAT(`UI::MPW`.Name,' ', `UI::TZ`.Name) as Name,"
                    . " `UI::TZ`.Id "
                    . "FROM"
                    . " `TEG_UI::TZ_R` "
                    . " LEFT JOIN `UI::TZ` ON `UI::TZ`.Id = `TEG_UI::TZ_R`.UITZId "
                    . " LEFT JOIN `UI::MPW` ON `UI::MPW`.Id = `UI::TZ`.MpwId "
                    . "WHERE"
                    . " `TEG_UI::TZ_R`.TEGId = " . $row["Id"] . " "
                    . "ORDER BY Name ";


            $resultUi = $mysqli->query($queryUi);
            if ($resultUi) {
                $uiList = array();
                $uiLists = array();
                while ($rowUi = $resultUi->fetch_assoc()) {
                    $uiList[] = $rowUi["Name"];
                    $uiLists[] = $rowUi;
                }
                $row["UI"] = implode("<br>", $uiList);
                $row["UIList"] = $uiLists;
            } else {
                $msg["AjaxError"] = "Ошибка в запросе:<br>" . $mysqli->error . "<br>$queryUi";
            }

            $queryUi = ""
                    . "SELECT"
                    . " CONCAT(`UI::MPW`.Name,' ', `UI::TZ`.Name) as Name,"
                    . " `UI::TZ`.Id "
                    . "FROM"
                    . " `UI::TZ` "
                    . " LEFT JOIN `UI::MPW` ON `UI::MPW`.Id = `UI::TZ`.MpwId "
                    . "WHERE"
                    . " `UI::TZ`.Id NOT IN ("
                    . " SELECT"
                    . "  `TEG_UI::TZ_R`.UITZId"
                    . " FROM"
                    . "  `TEG_UI::TZ_R`"
                    . " WHERE"
                    . "  `TEG_UI::TZ_R`.TEGId = " . $row["Id"] . ""
                    . " ) "
                    . "ORDER BY Name ";
            $resultUi = $mysqli->query($queryUi);
            if ($resultUi) {
                $uiList = array();
                while ($rowUi = $resultUi->fetch_assoc()) {
                    $uiList[] = $rowUi;
                }
                $row["UIDistinct"] = $uiList;
            } else {
                $msg["AjaxError"] = "Ошибка в запросе:<br>" . $mysqli->error . "<br>$queryUi";
            }

            //ячейки
            $queryC = ""
                    . "SELECT"
                    . " `TEG::Cell`.Id,"
                    . " `TEG::Cell`.Name "
                    . "FROM"
                    . " `TEG::Cell_TEG_R`"
                    . " LEFT JOIN `TEG::Cell` ON `TEG::Cell`.Id = `TEG::Cell_TEG_R`.CellId "
                    . "WHERE"
                    . " `TEG::Cell_TEG_R`.TegId = " . $row["Id"] . " "
                    . "ORDER BY `Name`";
            $resultC = $mysqli->query($queryC);
            if ($resultC) {
                $cells = array();
                $cellsI = array();
                while ($rowC = $resultC->fetch_assoc()) {
                    $queryTeg = ""
                            . "SELECT"
                            . " `TEG`.Path "
                            . "FROM"
                            . " `TEG::Cell_TEG_R` "
                            . " LEFT JOIN `TEG` ON `TEG`.Id = `TEG::Cell_TEG_R`.TegId "
                            . "WHERE"
                            . " `TEG::Cell_TEG_R`.CellId = " . $rowC["Id"] . " AND "
                            . " `TEG`.Id <> " . $_POST["tegId"] . " "
                            . "ORDER BY Path";
                    $resultTeg = $mysqli->query($queryTeg);
                    $tegList = array();
                    if ($resultTeg) {
                        while ($rowTeg = $resultTeg->fetch_assoc()) {
                            $tegList[] = end(explode("/", $rowTeg["Path"]));
                        }
                        $tegList = implode("<br>", $tegList);
                    } else {
                        $msg["AjaxError"] = "Ошибка в запросе:<br>" . $mysqli->error . "<br>$queryTeg";
                        break;
                    }

                    $queryRoute = ""
                            . "SELECT"
                            . " `TEG::Cell_BaseRoute_R`.Id, "
                            . " `TEG::Cell_BaseRoute_R`.Mandatory, "
                            . " `BaseRoute`.Name "
                            . "FROM"
                            . " `TEG::Cell_BaseRoute_R` "
                            . " LEFT JOIN `BaseRoute` ON `BaseRoute`.Id = `TEG::Cell_BaseRoute_R`.BaseRouteId "
                            . "WHERE"
                            . " `TEG::Cell_BaseRoute_R`.CellId = " . $rowC["Id"] . " "
                            . "ORDER BY `BaseRoute`.Name ";
                    $resultRoute = $mysqli->query($queryRoute);
                    $routeList = array();
                    if ($resultRoute) {
                        if ($resultRoute->num_rows > 0) {
                            while ($rowRoute = $resultRoute->fetch_assoc()) {
                                $routeList[] = $rowRoute;
                            }
                        } else {
                            $routeList = "";
                        }
                    } else {
                        $msg["AjaxError"] = "Ошибка в запросе:<br>" . $mysqli->error . "<br>$queryRoute";
                        break;
                    }

                    $cell = array();
                    $cell["Id"] = $rowC["Id"];
                    $cell["Name"] = $rowC["Name"];
                    $cell["TegList"] = $tegList;
                    $cell["RouteList"] = $routeList;
                    $cellsI[] = $cell;

                    if ($rowC["Id"] == $row["PrimaryCellId"]) {
                        $rowC["Name"] = "<strong>" . $rowC["Name"] . "</strong>";
                    }

                    $cells[] = $rowC["Name"];
                }
                $row["Cells"] = implode("<br>", $cells);
                $row["CellsInclude"] = $cellsI;
            } else {
                $msg["AjaxError"] = "Ошибка в запросе:<br>" . $mysqli->error . "<br>$queryC";
                break;
            }
            //Все другие ячейки
            $queryC = ""
                    . "SELECT"
                    . " `TEG::Cell`.Id,"
                    . " `TEG::Cell`.Name "
                    . "FROM"
                    . " `TEG::Cell` "
                    . "WHERE"
                    . " `TEG::Cell`.Id NOT IN ("
                    . "     SELECT"
                    . "      `TEG::Cell_TEG_R`.CellId "
                    . "     FROM"
                    . "      `TEG::Cell_TEG_R` "
                    . "     WHERE"
                    . "      `TEG::Cell_TEG_R`.TegId=" . $row["Id"] . " "
                    . " ) "
                    . "ORDER BY `Name`";
            $resultC = $mysqli->query($queryC);
            if ($resultC) {
                $cells = array();
                while ($rowC = $resultC->fetch_assoc()) {
                    $teg["Id"] = $rowC["Id"];
                    $teg["Name"] = $rowC["Name"];
                    $cells[] = $teg;
                }
                $row["DistinctCells"] = $cells;
            } else {
                $msg["AjaxError"] = "Ошибка в запросе:<br>" . $mysqli->error . "<br>$queryC";
            }
            //Все опорные ячейки 
            $queryC = ""
                    . "SELECT"
                    . " `TEG::Cell`.Id,"
                    . " `TEG::Cell`.Name "
                    . "FROM"
                    . " `TEG::Cell` "
                    . "ORDER BY `Name`";
            $resultC = $mysqli->query($queryC);
            if ($resultC) {
                $cells = array();
                while ($rowC = $resultC->fetch_assoc()) {
                    $teg["Id"] = $rowC["Id"];
                    $teg["Name"] = $rowC["Name"];
                    $cells[] = $teg;
                }
                $row["PrimaryCells"] = $cells;
            } else {
                $msg["AjaxError"] = "Ошибка в запросе:<br>" . $mysqli->error . "<br>$queryC";
            }
            $msg["TegInfo"] = $row;
        } else {
            $msg["AjaxError"] = "Ошибка в запросе:<br>" . $mysqli->error . "<br>$query";
        }
        break;
    case "getTegList":
        $query = ""
                . "SELECT"
                . " `TEG`.Id,"
                . " `TEG`.Path,"
                . " `TEG`.Orientation,"
                . " CONCAT(`TEG`.SizeX, 'x', `TEG`.SizeY) as Size,"
                . " `TEG`.CreationDate,"
                . " `TEG`.ExpirationDate "
                . "FROM"
                . " `TEG`"
                . "";
        $result = $mysqli->query($query);
        if ($result) {
            $msg["TegList"] = array();
            while ($row = $result->fetch_assoc()) {
                $row["Name"] = end(explode("/", $row["Path"]));
                $row["Route"] = "";
                if ($row["ExpirationDate"] != NULL) {
                    $row["Locked"] = 1;
                } else {
                    $row["Locked"] = 0;
                }
                $queryBR = ""
                        . "SELECT"
                        . " `BaseRoute`.Name,"
                        . " `BaseRoute`.Revision "
                        . "FROM"
                        . " `BaseRoute` "
                        . "WHERE"
                        . " `BaseRoute`.Id IN ("
                        . " SELECT"
                        . "  `TEG::Cell_BaseRoute_R`.BaseRouteId"
                        . " FROM "
                        . "  `TEG::Cell_TEG_R`"
                        . "  LEFT JOIN `TEG::Cell_BaseRoute_R` ON `TEG::Cell_BaseRoute_R`.CellId = `TEG::Cell_TEG_R`.CellId "
                        . " WHERE"
                        . "  `TEG::Cell_TEG_R`.TegId = " . $row["Id"] . " "
                        . " GROUP BY `BaseRouteId` "
                        . " HAVING COUNT(`BaseRouteId`) = ("
                        . "  SELECT"
                        . "   COUNT(`TEG::Cell_TEG_R`.Id)"
                        . "  FROM"
                        . "   `TEG::Cell_TEG_R` "
                        . "  WHERE"
                        . "   `TEG::Cell_TEG_R`.TegId = " . $row["Id"] . " "
                        . " )"
                        . ")";


                $resultBR = $mysqli->query($queryBR);
                if ($resultBR) {
                    $route = array();
                    while ($rowBR = $resultBR->fetch_assoc()) {
                        $route[] = $rowBR["Name"] . " <small>rev- " . $rowBR["Revision"] . "</small>";
                    }
                    $row["Route"] = implode("<br>", $route);
                } else {
                    $msg["AjaxError"] = "Ошибка в запросе:<br>" . $mysqli->error . "<br>$queryBR";
                }
                $msg["TegList"][] = $row;
            }
        } else {
            $msg["AjaxError"] = "Ошибка в запросе:<br>" . $mysqli->error . "<br>$query";
        }
        break;
    case "getRoute":
        $query = ""
                . "SELECT"
                . " `BaseRoute`.Id,"
                . " `BaseRoute`.Name,"
                . " `BaseRoute`.Revision "
                . "FROM"
                . " `BaseRoute`"
                . "ORDER BY `Name`, `Revision` ";
        $result = $mysqli->query($query);
        if ($result) {
            $msg["Routes"] = array();
            while ($row = $result->fetch_assoc()) {
                $route = array();
                $route["Id"] = $row["Id"];
                $route["Name"] = $row["Name"] . " <small>revision-" . $row["Revision"] . "</small>";
                $msg["Routes"][] = $route;
            }
        } else {
            $msg["AjaxError"] = "Ошибка в запросе:<br>" . $mysqli->error . "<br>$query";
        }
        break;
    case "updateMandatoryCell":
        $query = ""
                . "UPDATE"
                . " `TEG::Cell_BaseRoute_R` "
                . "SET"
                . " `Mandatory` = '" . $_POST['Value'] . "' "
                . "WHERE"
                . " Id = " . $_POST["Id"];
        $result = $mysqli->query($query);
        if ($result) {
            $msg["Success"] = "true";
        } else {
            $msg["AjaxError"] = "Ошибка в запросе:<br>" . $mysqli->error . "<br>$query";
        }
        break;
    case "updateTegPath":
        $query = ""
                . "UPDATE"
                . " `TEG` "
                . "SET"
                . " `Path` = '" . $_POST['value'] . "' "
                . "WHERE"
                . " Id = " . $_POST["tegId"];
        $result = $mysqli->query($query);
        if ($result) {
            $msg["Success"] = "true";
        } else {
            $msg["AjaxError"] = "Ошибка в запросе:<br>" . $mysqli->error . "<br>$query";
        }
        break;
    case "updateTegMd5":
        $query = ""
                . "UPDATE"
                . " `TEG` "
                . "SET"
                . " `Md5` = '" . $_POST['value'] . "' "
                . "WHERE"
                . " Id = " . $_POST["tegId"];
        $result = $mysqli->query($query);
        if ($result) {
            $msg["Success"] = "true";
        } else {
            $msg["AjaxError"] = "Ошибка в запросе:<br>" . $mysqli->error . "<br>$query";
        }
        break;
    case "updateTegSizeX":
        $query = ""
                . "UPDATE"
                . " `TEG` "
                . "SET"
                . " `SizeX` = " . $_POST['value'] . " "
                . "WHERE"
                . " Id = " . $_POST["tegId"];
        $result = $mysqli->query($query);
        if ($result) {
            $msg["Success"] = "true";
        } else {
            $msg["AjaxError"] = "Ошибка в запросе:<br>" . $mysqli->error . "<br>$query";
        }
        break;
    case "updateTegSizeY":
        $query = ""
                . "UPDATE"
                . " `TEG` "
                . "SET"
                . " `SizeY` = " . $_POST['value'] . " "
                . "WHERE"
                . " Id = " . $_POST["tegId"];
        $result = $mysqli->query($query);
        if ($result) {
            $msg["Success"] = "true";
        } else {
            $msg["AjaxError"] = "Ошибка в запросе:<br>" . $mysqli->error . "<br>$query";
        }
        break;
    case "updateTegOrientation":
        $query = ""
                . "UPDATE"
                . " `TEG` "
                . "SET"
                . " `Orientation` = '" . $_POST['value'] . "' "
                . "WHERE"
                . " Id = " . $_POST["tegId"];
        $result = $mysqli->query($query);
        if ($result) {
            $msg["Success"] = "true";
        } else {
            $msg["AjaxError"] = "Ошибка в запросе:<br>" . $mysqli->error . "<br>$query";
        }
        break;
    case "updateTegLocked":
        if ($_POST['value'] == 1) {
            $query = ""
                    . "UPDATE"
                    . " `TEG` "
                    . "SET"
                    . " `ExpirationDate` =  NOW() "
                    . "WHERE"
                    . " Id = " . $_POST["tegId"];
        } else {
            $query = ""
                    . "UPDATE"
                    . " `TEG` "
                    . "SET"
                    . " `ExpirationDate` = NULL "
                    . "WHERE"
                    . " Id = " . $_POST["tegId"];
        }
        $result = $mysqli->query($query);
        if ($result) {
            $msg["Success"] = "true";
        } else {
            $msg["AjaxError"] = "Ошибка в запросе:<br>" . $mysqli->error . "<br>$query";
        }
        break;
    case "updateTegPrimaryCell":
        $query = ""
                . "UPDATE"
                . " `TEG` "
                . "SET"
                . " `PrimaryCellId` = " . $_POST['value'] . " "
                . "WHERE"
                . " Id = " . $_POST["tegId"];
        $result = $mysqli->query($query);
        if ($result) {
            $msg["Success"] = "true";
        } else {
            $msg["AjaxError"] = "Ошибка в запросе:<br>" . $mysqli->error . "<br>$query";
        }
        break;
    case "uploadCellIni":
        if (is_uploaded_file($_FILES["filename"]["tmp_name"])) {
            $cells = parse_ini_file($_FILES["filename"]["tmp_name"], true);
            $tegName = end(explode("/", $_POST["path"]));
            if (isset($cells["$tegName"])) {
                $array = array();
                $msg["Md5"] = $cells["$tegName"]["md5sum"];
                foreach ($cells["$tegName"] as $key => $value) {
                    if (stripos($key, "cell_") === 0) {

                        $checkCellRow = true;

                        if (isset($_POST["startRowTeg"])) {
                            if (stripos($cells["$tegName"][$key], "TEG_") !== 0) {
                                $checkCellRow = false;
                            }
                        }
                        if (isset($_POST["endRowTeg"])) {
                            if (!preg_match("/V[0-9]{1,}$/", $cells["$tegName"][$key])) {
                                $checkCellRow = false;
                            }
                        }
                        if (isset($_POST["endRowTegDummy"])) {
                            if (!preg_match("/_DUMMIES$/", $cells["$tegName"][$key])) {
                                $checkCellRow = false;
                            }
                        }
                        if ($checkCellRow) {
                            $cell = array();
                            $cell["Name"] = $cells["$tegName"][$key];
                            $query = ""
                                    . "SELECT"
                                    . " `TEG::Cell`.Id "
                                    . "FROM"
                                    . " `TEG::Cell` "
                                    . "WHERE"
                                    . " `TEG::Cell`.Name = '" . $cell["Name"] . "'";
                            $result = $mysqli->query($query);

                            if ($result) {
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        $cell["Id"] = $row["Id"];

                                        $queryTeg = ""
                                                . "SELECT"
                                                . " `TEG`.Path "
                                                . "FROM"
                                                . " `TEG::Cell_TEG_R` "
                                                . " LEFT JOIN `TEG` ON `TEG`.Id = `TEG::Cell_TEG_R`.TegId "
                                                . "WHERE"
                                                . " `TEG::Cell_TEG_R`.CellId = " . $row["Id"] . " "
                                                . "ORDER BY Path";
                                        $resultTeg = $mysqli->query($queryTeg);
                                        $tegList = array();
                                        if ($resultTeg) {
                                            while ($rowTeg = $resultTeg->fetch_assoc()) {
                                                $tegList[] = end(explode("/", $rowTeg["Path"]));
                                            }
                                            $tegList = implode("<br>", $tegList);
                                        } else {
                                            $msg["AjaxError"] = "Ошибка в запросе:<br>" . $mysqli->error . "<br>$queryTeg";
                                            break;
                                        }

                                        $queryRoute = ""
                                                . "SELECT"
                                                . " `TEG::Cell_BaseRoute_R`.Id, "
                                                . " `TEG::Cell_BaseRoute_R`.Mandatory, "
                                                . " `BaseRoute`.Name "
                                                . "FROM"
                                                . " `TEG::Cell_BaseRoute_R` "
                                                . " LEFT JOIN `BaseRoute` ON `BaseRoute`.Id = `TEG::Cell_BaseRoute_R`.BaseRouteId "
                                                . "WHERE"
                                                . " `TEG::Cell_BaseRoute_R`.CellId = " . $row["Id"] . " "
                                                . "ORDER BY `BaseRoute`.Name ";
                                        $resultRoute = $mysqli->query($queryRoute);
                                        $routeList = array();
                                        if ($resultRoute) {

                                            while ($rowRoute = $resultRoute->fetch_assoc()) {
                                                if ($rowRoute["Mandatory"] == 1) {
                                                    $rowRoute["Name"] = "<strong>" . $rowRoute["Name"] . "</strong>";
                                                }
                                                $routeList[] = $rowRoute["Name"];
                                            }
                                            $routeList = implode("<br>", $routeList);
                                        } else {
                                            $msg["AjaxError"] = "Ошибка в запросе:<br>" . $mysqli->error . "<br>$queryRoute";
                                            break;
                                        }

                                        $cell["TegList"] = $tegList;
                                        $cell["RouteList"] = $routeList;
                                        $array[] = $cell;
                                    }
                                } else {
                                    $cell["Id"] = "";
                                    $array[] = $cell;
                                }
                            }
                        }
                    }
                }
                $msg["Content"] = $array;
            } else {
                $msg["AjaxError"] = "В загруженном файле нету указанной сборки.";
            }
        } else {
            $msg["AjaxError"] = "Не удалось загрузить файл на сервер.";
        }
        break;
    default:
        $msg['AjaxError'] = "Не корректный ключ запроса.";
}

echo json_encode($msg);
?>