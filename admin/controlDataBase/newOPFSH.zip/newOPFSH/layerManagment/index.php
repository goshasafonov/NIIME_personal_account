<?php

define('APP', true);
include_once ("./../config.php");
include_once ("./../header.php");

$page = file_get_contents("./page.html");
$page = str_replace("%\$host%", $host, $page);
$page = str_replace("%\$versionSite%", $versionSite, $page);
$page = $page . "<input id=\"pathAjax\" value=\"$host/layerManagment/ajax.php\" type=\"hidden\">";
$page = $page . "<script src='$host/layerManagment/content.js'></script>";
echo $page;

include_once ("./../fouter.php");
?>
