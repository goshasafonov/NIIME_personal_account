<?php

defined('APP') or die('Access denied!');
$host = "http://mikron-ftpincheck/newOPFSH";
$versionSite = "1.4.1";
$db_mysql_user_login = "php_checkDB_v2";
$db_mysql_user_paswd = "XH55bf5d5y5SbThA";
$db_mysql_database = "newOPFSHV2";
$db_mysql_host = "aryabinin";

//Другой сервер    
//$host = "http://aryabinin";
?>
