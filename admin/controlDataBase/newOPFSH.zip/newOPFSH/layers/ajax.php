<?php

$msg = array();
require_once "./login.php";
if (isset($msg["AjaxError"])) {
    echo json_encode($msg);
    exit();
}

$queryId = $_POST['queryId'];
switch ($queryId) {
    case "getAllLayers":
        $query = ""
                . "SELECT"
                . " `Layer`.Id,"
                . " `Layer`.Layer,"
                . " `Layer`.Name, "
                . " `Layer`.Comment,"
                . " COUNT(`Layer::Cad`.LayerId) as Cad,"
                . " COUNT(`Layer::Intermediate`.LayerId) as Intermediate,"
                . " COUNT(`Layer::Mask`.LayerId) as Mask "
                . "FROM"
                . " `Layer` "
                . " LEFT JOIN `Layer::Cad` ON `Layer::Cad`.`LayerId` = `Layer`.Id "
                . " LEFT JOIN `Layer::Intermediate` ON `Layer::Intermediate`.`LayerId` = `Layer`.Id "
                . " LEFT JOIN `Layer::Mask` ON `Layer::Mask`.`LayerId` = `Layer`.Id "
                . "GROUP BY Id "
                . "ORDER BY `Id` ";

        $result = mysql_query($query);
        if ($result) {
            $msg["AllLayers"] = array();
            while ($row = mysql_fetch_assoc($result)) {

                $row["Attribute"] = "";

                if ($row["Cad"] == 1) {
                    $queryCad = ""
                            . "SELECT"
                            . " `Layer::Cad`.Id,"
                            . " `Layer::Forbidding`.Id as ForbiddingId,"
                            . " `Layer::Suspended`.Id as SuspendedId,"
                            . " `Layer::Merging`.Id as MergingId,"
                            . " `Layer::Merging`.Base,"
                            . " `Layer::Merging`.Dummy "
                            . "FROM"
                            . " `Layer::Cad`"
                            . " LEFT JOIN `Layer::Forbidding` ON `Layer::Forbidding`.CadLayerId = `Layer::Cad`.Id"
                            . " LEFT JOIN `Layer::Suspended` ON `Layer::Suspended`.CadLayerId = `Layer::Cad`.Id"
                            . " LEFT JOIN `Layer::Merging` ON `Layer::Merging`.CadLayerId = `Layer::Cad`.Id "
                            . "WHERE"
                            . " `Layer::Cad`.`LayerId` = " . $row["Id"];
                    $resultCad = mysql_query($queryCad);
                    if ($resultCad) {
                        $rowCad = mysql_fetch_assoc($resultCad);
                        if ($rowCad["ForbiddingId"] != NULL) {
                            $row['Attribute'] = "Id: " . $rowCad["Id"] . "-" . $rowCad["ForbiddingId"] . "<br>Forbidding слой";
                        } else if ($rowCad["SuspendedId"] != NULL) {
                            $row['Attribute'] = "Id: " . $rowCad["Id"] . "-" . $rowCad["SuspendedId"] . "<br>Suspended слой";
                        } else if ($rowCad["MergingId"] != NULL) {
                            $row['Attribute'] = "Id: " . $rowCad["Id"] . "-" . $rowCad["MergingId"] . "<br>Merging слой";
                            if ($rowCad["Base"] == 1) {
                                $row['Attribute'] = $row['Attribute']."<br>Базовый";
                            }
                            if ($rowCad["Dummy"] == 1) {
                                $row['Attribute'] = $row['Attribute']."<br>Dummy";
                            }
                        }
                    } else {
                        $row['Attribute'] = "$queryId: Ошибка в запросе.<br>" . mysql_error($db_mysql_server);
                    }
                } else if ($row["Intermediate"] == 1) {
                    $queryInt = ""
                            . "SELECT"
                            . " `Layer::Intermediate`.Id,"
                            . " `Layer::Intermediate`.Mark,"
                            . " `Layer::Intermediate`.Density "
                            . "FROM"
                            . " `Layer::Intermediate`"
                            . "WHERE"
                            . " `Layer::Intermediate`.`LayerId` = " . $row["Id"];
                    $resultInt = mysql_query($queryInt);
                    if ($resultInt) {
                        $rowInt = mysql_fetch_assoc($resultInt);
                        $row['Attribute'] = "Id: " . $rowInt["Id"]."<br>Intermediate слой";                        
                        if ($rowInt["Mark"] == 1) {
                            $row['Attribute'] = $row['Attribute']."<br>Mark";
                        }
                        if ($rowInt["Density"] == 1) {
                            $row['Attribute'] = $row['Attribute']."<br>Density";
                        }                        
                       
                    } else {
                        $row['Attribute'] = "$queryId: Ошибка в запросе.<br>" . mysql_error($db_mysql_server);
                    }
                } else if ($row["Mask"] == 1) {
                   $queryMask = ""
                            . "SELECT"
                            . " `Layer::Mask`.Id,"
                            . " `Layer::Mask`.Mark "
                            . "FROM"
                            . " `Layer::Mask`"
                            . "WHERE"
                            . " `Layer::Mask`.`LayerId` = " . $row["Id"];
                    $resultMask = mysql_query($queryMask);
                    if ($resultMask) {
                        $rowMask = mysql_fetch_assoc($resultMask);
                        $row['Attribute'] = "Id: " . $rowMask["Id"]."<br>Mask слой";                        
                        if ($rowInt["Mark"] == 1) {
                            $row['Attribute'] = $row['Attribute']."<br>Mark";
                        }                        
                    } else {
                        $row['Attribute'] = "$queryId: Ошибка в запросе.<br>" . mysql_error($db_mysql_server);
                    } 
                }

                //Базовые маршруты
                $queryBR = ""
                        . "SELECT"
                        . " `BaseRoute`.Name "
                        . "FROM"
                        . " `Layer_BaseRoute_R` "
                        . " LEFT JOIN `BaseRoute` ON `BaseRoute`.Id = `Layer_BaseRoute_R`.`BaseRouteId`"
                        . "WHERE"
                        . " `Layer_BaseRoute_R`.LayerId = " . $row['Id'];
                $resultBR = mysql_query($queryBR);
                if ($resultBR) {
                    $row["BaseRoutes"] = "";

                    while ($rowBR = mysql_fetch_assoc($resultBR)) {
                        $row["BaseRoutes"][] = $rowBR["Name"];
                    }
                    $row["BaseRoutes"] = implode("<br>", $row["BaseRoutes"]);
                } else {
                    $msg['AjaxError'] = "$queryId: Ошибка в запросе.<br>" . mysql_error($db_mysql_server);
                    break;
                }
                //Опции
                $queryOPT = ""
                        . "SELECT"
                        . " `Option`.Name "
                        . "FROM"
                        . " `Layer_Option_R` "
                        . " LEFT JOIN `Option` ON `Option`.Id = `Layer_Option_R`.`OptionId` "
                        . "WHERE"
                        . " `Layer_Option_R`.`LayerId` = " . $row['Id'];
                $resultOPT = mysql_query($queryOPT);
                if ($resultOPT) {
                    $row["Options"] = "";

                    while ($rowOPT = mysql_fetch_assoc($resultOPT)) {
                        $row["Options"][] = $rowOPT["Name"];
                    }
                    $row["Options"] = implode("<br>", $row["Options"]);
                } else {
                    $msg['AjaxError'] = "$queryId: Ошибка в запросе.<br>" . mysql_error($db_mysql_server);
                    break;
                }


                $msg["AllLayers"][] = $row;
            }
        } else {
            $msg['AjaxError'] = "$queryId: Ошибка в запросе.<br>" . mysql_error($db_mysql_server);
        }
        break;
    case "getContentCadLayersLevel1":
        $query = ""
                . "SELECT"
                . " `Layer`.Id as LayerId,"
                . " `Layer`.Layer as Layer,"
                . " `Layer`.Name as LayerName,"
                . " `Layer::Cad`.Id as CadLayerId,"
                . " `Layer::Forbidding`.Id as ForbiddingLyaerId,"
                . " `Layer::Suspended`.Id as SuspendedLayerId,"
                . " `Layer::Merging`.Id as MergingLayerId,"
                . " `Layer::Merging`.Base as MergingLayerBase,"
                . " `Layer::Merging`.Dummy as MergingLayerDummy "
                . "FROM"
                . " `Layer_BaseRoute_R`"
                . " LEFT JOIN `Layer` ON `Layer`.Id = `Layer_BaseRoute_R`.LayerId "
                . " LEFT JOIN `Layer::Cad` ON `Layer::Cad`.LayerId = `Layer`.Id "
                . " LEFT JOIN `Layer::Forbidding` ON `Layer::Forbidding`.CadLayerId = `Layer::Cad`.Id "
                . " LEFT JOIN `Layer::Suspended` ON `Layer::Suspended`.CadLayerId = `Layer::Cad`.Id "
                . " LEFT JOIN `Layer::Merging` ON `Layer::Merging`.CadLayerId = `Layer::Cad`.Id "
                . "WHERE"
                . " `Layer_BaseRoute_R`.BaseRouteId = " . $_POST['route'] . " AND"
                . " `Layer::Cad`.Id IS NOT NULL "
                . "ORDER BY `LayerId`";
        $result = mysql_query($query);
        if ($result) {
            $msg["CadLayersLevel1"] = array();
            while ($row = mysql_fetch_assoc($result)) {
                if ($row["MergingLayerBase"] == 1) {
                    $row["MergingLayerBase"] = "+";
                } else {
                    $row["MergingLayerBase"] = "";
                }
                if ($row["MergingLayerDummy"] == 1) {
                    $row["MergingLayerDummy"] = "+";
                } else {
                    $row["MergingLayerDummy"] = "";
                }
                $msg["CadLayersLevel1"][] = $row;
            }
        } else {
            $msg['AjaxError'] = "$queryId: Ошибка в запросе.<br>" . mysql_error($db_mysql_server);
        }
        break;
    case "getContentCadLayersLevel2":
        $query = ""
                . "SELECT"
                . " `MergingLayerName`.Name as MergingGeneralLayerName,"
                . " `MergingLayerName`.Layer as MergingGeneralLayer,"
                . " `MergingLayerCad`.LayerId as MergingGeneralLayerId,"
                . " `Layer::Merging`.`CadLayerId` as MergingCadLayerId,"
                . " `Layer::Merging_Layer::Forbidding_R`.MergingLayerId,"
                . " `Layer::Merging_Layer::Forbidding_R`.ForbiddingLayerId,"
                . " `Layer::Forbidding`.`CadLayerId` as ForbidingCadLayerId,"
                . " `ForbidingLayerCad`.LayerId as ForbidingGeneralLayerId,"
                . " `ForbidingLayerName`.Name as ForbidingGeneralLayerName,"
                . " `ForbidingLayerName`.Layer as ForbidingGeneralLayer "
                . "FROM"
                . " `Layer::Merging_Layer::Forbidding_R`"
                . " LEFT JOIN `Layer::Merging` ON `Layer::Merging`.Id = `Layer::Merging_Layer::Forbidding_R`.MergingLayerId"
                . " LEFT JOIN `Layer::Cad` as `MergingLayerCad` ON `MergingLayerCad`.Id = `Layer::Merging`.CadLayerId"
                . " LEFT JOIN `Layer` as `MergingLayerName` ON `MergingLayerName`.Id = `MergingLayerCad`.LayerId"
                . " LEFT JOIN `Layer::Forbidding` ON `Layer::Forbidding`.Id = `Layer::Merging_Layer::Forbidding_R`.ForbiddingLayerId"
                . " LEFT JOIN `Layer::Cad` as `ForbidingLayerCad` ON `ForbidingLayerCad`.Id = `Layer::Forbidding`.CadLayerId"
                . " LEFT JOIN `Layer` as `ForbidingLayerName` ON `ForbidingLayerName`.Id = `ForbidingLayerCad`.LayerId"
                . " LEFT JOIN `Layer_BaseRoute_R` as `MergingLayerBaseRouteR` ON `MergingLayerBaseRouteR`.LayerId = `MergingLayerName`.Id"
                . " LEFT JOIN `Layer_BaseRoute_R` as `ForbiddingLayerBaseRouteR` ON `ForbiddingLayerBaseRouteR`.LayerId = `ForbidingLayerName`.Id "
                . "WHERE"
                . " `MergingLayerBaseRouteR`.BaseRouteId = " . $_POST["route"] . " AND"
                . " `ForbiddingLayerBaseRouteR`.BaseRouteId = " . $_POST["route"];

        $result = mysql_query($query);
        if ($result) {
            $msg["CadLayersLevel2"] = array();
            while ($row = mysql_fetch_assoc($result)) {
                $tmpRow = array();
                $tmpRow["ForbiddingLayerId"] = $row["ForbidingGeneralLayerId"] . "-" . $row["ForbidingCadLayerId"] . "-" . $row["ForbiddingLayerId"];
                $tmpRow["ForbiddingLayerName"] = $row["ForbidingGeneralLayerName"];
                $tmpRow["ForbiddingLayer"] = $row["ForbidingGeneralLayer"];
                $tmpRow["MergingLayerId"] = $row["MergingGeneralLayerId"] . "-" . $row["MergingCadLayerId"] . "-" . $row["MergingLayerId"];
                $tmpRow["MergingLayerName"] = $row["MergingGeneralLayerName"];
                $tmpRow["MergingLayer"] = $row["MergingGeneralLayer"];
                $msg["CadLayersLevel2"][] = $tmpRow;
            }
        } else {
            $msg['AjaxError'] = "$queryId: Ошибка в запросе.<br>" . mysql_error($db_mysql_server) . "<br>$query";
        }
        break;
    case "getContentIntermediatesLayersLevel1" :
        $query = ""
                . "SELECT"
                . " `Layer`.Id as LayerId,"
                . " `Layer`.Layer as Layer,"
                . " `Layer`.Name as LayerName,"
                . " `Layer::Intermediate`.Id as IntermediateLayerId,"
                . " `Layer::Intermediate`.Mark as IntermediatesLayerMark,"
                . " `Layer::Intermediate`.Density as IntermediatesDensity "
                . "FROM"
                . " `Layer_BaseRoute_R`"
                . " LEFT JOIN `Layer` ON `Layer`.Id = `Layer_BaseRoute_R`.LayerId "
                . " LEFT JOIN `Layer::Intermediate` ON `Layer::Intermediate`.LayerId = `Layer`.Id "
                . "WHERE"
                . " `Layer_BaseRoute_R`.BaseRouteId = " . $_POST['route'] . " AND"
                . " `Layer::Intermediate`.Id IS NOT NULL "
                . "ORDER BY `LayerId`";
        $result = mysql_query($query);
        if ($result) {
            $msg["IntermediatesLayersLevel1"] = array();
            while ($row = mysql_fetch_assoc($result)) {
                if ($row["IntermediatesLayerMark"] == 1) {
                    $row["IntermediatesLayerMark"] = "+";
                } else {
                    $row["IntermediatesLayerMark"] = "";
                }
                if ($row["IntermediatesDensity"] == 1) {
                    $row["IntermediatesDensity"] = "+";
                } else {
                    $row["IntermediatesDensity"] = "";
                }
                $msg["IntermediatesLayersLevel1"][] = $row;
            }
        } else {
            $msg['AjaxError'] = "$queryId: Ошибка в запросе.<br>" . mysql_error($db_mysql_server);
        }
        break;
    case "getContentIntermediatesLayersLevel2":
        $query = ""
                . "SELECT"
                . " `MergingLayerName`.Name as MergingGeneralLayerName,"
                . " `MergingLayerName`.Layer as MergingGeneralLayer,"
                . " `MergingLayerCad`.LayerId as MergingGeneralLayerId,"
                . " `Layer::Merging`.`CadLayerId` as MergingCadLayerId,"
                . " `Layer::Intermediate_Layer::Merging_R`.MergingLayerId,"
                . " `Layer::Intermediate_Layer::Merging_R`.IntermediateLayerId,"
                . " `Layer::Intermediate`.LayerId as IntermediateGeneralLayerId,"
                . " `IntermediateLayerName`.Name as  IntermediateGeneralLayerName,"
                . " `IntermediateLayerName`.Layer as IntermediateGenerealLayer "
                . "FROM"
                . " `Layer::Intermediate_Layer::Merging_R`"
                . " LEFT JOIN `Layer::Merging` ON `Layer::Merging`.Id = `Layer::Intermediate_Layer::Merging_R`.MergingLayerId"
                . " LEFT JOIN `Layer::Cad` as `MergingLayerCad` ON `MergingLayerCad`.Id = `Layer::Merging`.CadLayerId"
                . " LEFT JOIN `Layer` as `MergingLayerName` ON `MergingLayerName`.Id = `MergingLayerCad`.LayerId"
                . " LEFT JOIN `Layer_BaseRoute_R` as `MergingLayerBaseRouteR` ON `MergingLayerBaseRouteR`.LayerId = `MergingLayerName`.Id"
                . " LEFT JOIN `Layer::Intermediate` ON `Layer::Intermediate`.Id = `Layer::Intermediate_Layer::Merging_R`.IntermediateLayerId"
                . " LEFT JOIN `Layer` as `IntermediateLayerName` ON `IntermediateLayerName`.Id = `Layer::Intermediate`.LayerId "
                . " LEFT JOIN `Layer_BaseRoute_R` as `IntermediateLayerBaseRouteR` ON `IntermediateLayerBaseRouteR`.LayerId = `IntermediateLayerName`.Id "
                . "WHERE "
                . " `MergingLayerBaseRouteR`.BaseRouteId = " . $_POST["route"] . " AND"
                . " `IntermediateLayerBaseRouteR`.BaseRouteId = " . $_POST["route"];

        $result = mysql_query($query);
        if ($result) {
            $msg["IntermediateLayersLevel2"] = array();
            while ($row = mysql_fetch_assoc($result)) {
                $tmpRow = array();
                $tmpRow["IntermediateLayerId"] = $row["IntermediateGeneralLayerId"] . "-" . $row["IntermediateLayerId"];
                $tmpRow["IntermediateLayerName"] = $row["IntermediateGeneralLayerName"];
                $tmpRow["IntermediateLayer"] = $row["IntermediateGenerealLayer"];
                $tmpRow["MergingLayerId"] = $row["MergingGeneralLayerId"] . "-" . $row["MergingCadLayerId"] . "-" . $row["MergingLayerId"];
                $tmpRow["MergingLayerName"] = $row["MergingGeneralLayerName"];
                $tmpRow["MergingLayer"] = $row["MergingGeneralLayer"];
                $msg["IntermediateLayersLevel2"][] = $tmpRow;
            }
        } else {
            $msg['AjaxError'] = "$queryId: Ошибка в запросе.<br>" . mysql_error($db_mysql_server) . "<br>$query";
        }
        break;
    case "getContentMaskLayersLevel1":
        $query = ""
                . "SELECT"
                . " `Layer`.Id as LayerId,"
                . " `Layer`.Layer as Layer,"
                . " `Layer`.Name as LayerName,"
                . " `Layer::Mask`.Id as MaskLayerId,"
                . " `Layer::Mask`.Mark as MaskLayerMark "
                . "FROM"
                . " `Layer_BaseRoute_R`"
                . " LEFT JOIN `Layer` ON `Layer`.Id = `Layer_BaseRoute_R`.LayerId "
                . " LEFT JOIN `Layer::Mask` ON `Layer::Mask`.LayerId = `Layer`.Id "
                . "WHERE"
                . " `Layer_BaseRoute_R`.BaseRouteId = " . $_POST['route'] . " AND"
                . " `Layer::Mask`.Id IS NOT NULL "
                . "ORDER BY `LayerId`";
        $result = mysql_query($query);
        if ($result) {
            $msg["MasksLayersLevel1"] = array();
            while ($row = mysql_fetch_assoc($result)) {
                if ($row["MaskLayerMark"] == 1) {
                    $row["MaskLayerMark"] = "+";
                } else {
                    $row["MaskLayerMark"] = "";
                }
                $msg["MasksLayersLevel1"][] = $row;
            }
        } else {
            $msg['AjaxError'] = "$queryId: Ошибка в запросе.<br>" . mysql_error($db_mysql_server);
        }
        break;
    case "getContentMaskLayersLevel2":
        $query = ""
                . "SELECT"
                . " `Layer::Mask_Layer::Intermediate_R`.IntermediateLayerId,"
                . " `Layer::Intermediate`.LayerId as IntermediateGeneralLayerId,"
                . " `IntermediateLayerName`.Name as  IntermediateGeneralLayerName,"
                . " `IntermediateLayerName`.Layer as IntermediateGenerealLayer,"
                . " `Layer::Mask_Layer::Intermediate_R`.MaskLayerId,"
                . " `Layer::Mask`.LayerId as MaskGeneralLayerId,"
                . " `MaskLayerName`.Name as MaskGeneralLayerName,"
                . " `MaskLayerName`.Layer as MaskGenerealLayer "
                . "FROM"
                . " `Layer::Mask_Layer::Intermediate_R`"
                . " LEFT JOIN `Layer::Intermediate` ON `Layer::Intermediate`.Id = `Layer::Mask_Layer::Intermediate_R`.IntermediateLayerId"
                . " LEFT JOIN `Layer` as `IntermediateLayerName` ON `IntermediateLayerName`.Id = `Layer::Intermediate`.LayerId "
                . " LEFT JOIN `Layer_BaseRoute_R` as `IntermediateLayerBaseRouteR` ON `IntermediateLayerBaseRouteR`.LayerId = `IntermediateLayerName`.Id "
                . " LEFT JOIN `Layer::Mask` ON `Layer::Mask`.Id = `Layer::Mask_Layer::Intermediate_R`.MaskLayerId "
                . " LEFT JOIN `Layer` as `MaskLayerName` ON `MaskLayerName`.Id = `Layer::Mask`.LayerId "
                . " LEFT JOIN `Layer_BaseRoute_R` as `MaskLayerBaseRouteR` ON `MaskLayerBaseRouteR`.LayerId = `MaskLayerName`.Id "
                . "WHERE "
                . " `MaskLayerBaseRouteR`.BaseRouteId = " . $_POST["route"] . " AND"
                . " `IntermediateLayerBaseRouteR`.BaseRouteId = " . $_POST["route"];

        $result = mysql_query($query);
        if ($result) {
            $msg["MaskLayersLevel2"] = array();
            while ($row = mysql_fetch_assoc($result)) {
                $tmpRow = array();
                $tmpRow["IntermediateLayerId"] = $row["IntermediateGeneralLayerId"] . "-" . $row["IntermediateLayerId"];
                $tmpRow["IntermediateLayerName"] = $row["IntermediateGeneralLayerName"];
                $tmpRow["IntermediateLayer"] = $row["IntermediateGenerealLayer"];
                $tmpRow["MaskLayerId"] = $row["MaskGeneralLayerId"] . "-" . $row["MaskLayerId"];
                $tmpRow["MaskLayerName"] = $row["MaskGeneralLayerName"];
                $tmpRow["MaskLayer"] = $row["MaskGenerealLayer"];

                $msg["MaskLayersLevel2"][] = $tmpRow;
            }
        } else {
            $msg['AjaxError'] = "$queryId: Ошибка в запросе.<br>" . mysql_error($db_mysql_server) . "<br>$query";
        }
        break;
    case "getRoute":
        $query = ""
                . "SELECT"
                . " `BaseRoute`.`Id`, "
                . " `BaseRoute`.`Name`, "
                . " `BaseRoute`.`Revision` "
                . "FROM"
                . " `BaseRoute` "
                . "WHERE"
                . " `BaseRoute`.`TechnologyId` = " . $_POST['technology'] . " "
                . "ORDER BY `Name`, `Revision`";
        $result = mysql_query($query);
        if ($result) {
            $msg["RouteList"] = array();
            while ($row = mysql_fetch_assoc($result)) {
                $tmpRow["Id"] = $row["Id"];
                $tmpRow["Name"] = $row["Name"] . " <small>revision: " . $row['Revision'] . "</small>";
                $msg["RouteList"][] = $tmpRow;
            }
        } else {
            $msg['AjaxError'] = "$queryId: Ошибка в запросе.";
        }
        break;
    case "getTechnologyList":
        $query = ""
                . "SELECT"
                . " `Technology`.`Id`,"
                . " `Technology`.`Name` "
                . "FROM"
                . " `Technology` "
                . "ORDER BY `Name`";
        $result = mysql_query($query);
        if ($result) {
            $msg["TechnologyList"] = array();
            while ($row = mysql_fetch_assoc($result)) {
                $msg["TechnologyList"][] = $row;
            }
        } else {
            $msg['AjaxError'] = "$queryId: Ошибка в запросе.";
        }
        break;
    default:
        $msg['AjaxError'] = "Не корректный ключ запроса.";
}

echo json_encode($msg);
?>