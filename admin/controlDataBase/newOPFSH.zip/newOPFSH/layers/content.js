/*global checkboxHideCommentLayersAllLayersTable, checkboxHideMaskLayersAllLayersTable, checkboxHideIntermediateLayersAllLayersTable, checkboxHideCadLayersAllLayersTable, checkboxHideOptLayersAllLayersTable,checkboxHideBaseRoutesLayersAllLayersTable, allLayersTable, maskLayersTableLevel2, checkboxHideMaskMarkLayersTableLevel1, checkboxHideMaskEmptyLayersTableLevel1, maskLayersTableLevel1, intermediateLayersTableLevel2, checkboxHideIntermediateDensityLayersTableLevel1, checkboxHideIntermediateMarkLayersTableLevel1, checkboxHideIntermediateEmptyLayersTableLevel1, checkboxHideMergingDummyLayersCadLayersTableLevel1, checkboxHideMergingBaseLayersCadLayersTableLevel1, checkboxHideMergingEmptyLayersCadLayersTableLevel1, intermediateLayersTableLevel1, checkboxHideSuspendedLayersCadLayersTableLevel1, formRoutes, checkboxHideForbidingLayersCadLayersTableLevel1, formTechnology, pathAjax, technologySelect, cadLayersTableLevel1, cadLayersTableLevel2, routesCheckbox, modalAlertBody, layersPage*/

function alertMsg(text) {
    modalAlertBody.innerHTML = text;
    $('#modalAlert').modal('show');
}

function clearRoute() {
    routesCheckbox.innerHTML = "";
    var label = document.createElement("label");
    label.innerHTML = "Маршруты:";
    routesCheckbox.appendChild(label);
    clearTableCadLayers();
    clearTableInetrmediateLayers();
}

function clearTableCadLayers() {
    cadLayersTableLevel1.children[1].innerHTML = "";
    cadLayersTableLevel2.children[1].innerHTML = "";
    cadLayersTableLevel1.hidden = true;
    cadLayersTableLevel2.hidden = true;

    checkboxHideForbidingLayersCadLayersTableLevel1.disabled = true;
    checkboxHideSuspendedLayersCadLayersTableLevel1.disabled = true;
    checkboxHideMergingEmptyLayersCadLayersTableLevel1.disabled = true;
    checkboxHideMergingBaseLayersCadLayersTableLevel1.disabled = true;
    checkboxHideMergingDummyLayersCadLayersTableLevel1.disabled = true;
}

function clearTableInetrmediateLayers() {
    intermediateLayersTableLevel1.children[1].innerHTML = "";
    intermediateLayersTableLevel2.children[1].innerHTML = "";
    intermediateLayersTableLevel1.hidden = true;
    intermediateLayersTableLevel2.hidden = true;

    checkboxHideIntermediateEmptyLayersTableLevel1.disabled = true;
    checkboxHideIntermediateMarkLayersTableLevel1.disabled = true;
    checkboxHideIntermediateDensityLayersTableLevel1.disabled = true;
}

function clearTableMaskLayers() {
    maskLayersTableLevel1.children[1].innerHTML = "";
    maskLayersTableLevel2.children[1].innerHTML = "";
    maskLayersTableLevel1.hidden = true;
    maskLayersTableLevel2.hidden = true;

    checkboxHideMaskEmptyLayersTableLevel1.disabled = true;
    checkboxHideMaskMarkLayersTableLevel1.disabled = true;
}

function createBaseRouteRadiokBox(parentForm, checkboxId, checkboxValue, labelText) {
    var div = document.createElement("div");
    var input = document.createElement("input");
    var label = document.createElement("label");
    div.setAttribute("class", "custom-control custom-radio");
    input.type = "radio";
    input.setAttribute("class", "custom-control-input");
    input.id = checkboxId;
    input.value = checkboxValue;
    input.name = "route";
    input.setAttribute("onchange", "getRouteContent()");
    label.setAttribute("class", "custom-control-label");
    label.setAttribute("for", checkboxId);
    label.innerHTML = labelText;
    parentForm.appendChild(div);
    div.appendChild(input);
    div.appendChild(label);
}

function getAllLayers() {
    allLayersTable.children[1].innerHTML = "";
    checkboxHideBaseRoutesLayersAllLayersTable.disabled = true;
    checkboxHideOptLayersAllLayersTable.disabled = true;
    checkboxHideCadLayersAllLayersTable.disabled = true;
    checkboxHideIntermediateLayersAllLayersTable.disabled = true;
    checkboxHideMaskLayersAllLayersTable.disabled = true;
    checkboxHideCommentLayersAllLayersTable.disabled = true;

    var formData = new FormData(formRoutes);
    formData.append('queryId', 'getAllLayers');

    $.ajax({
        url: pathAjax.value,
        type: 'POST',
        data: formData,
        processData: false,
        contentType: false,
        success: function (data) {
            try {
                var jsonData = JSON.parse(data);
                if (typeof jsonData.AjaxError !== "undefined") {
                    alertMsg(jsonData.AjaxError);
                } else if (typeof jsonData.AllLayers !== "undefined") {
                    var tbody = allLayersTable.children[1];
                    for (var key in jsonData.AllLayers) {
                        var row = tbody.insertRow(tbody.rows.length);
                        var cellLayerId = row.insertCell(row.length);
                        var cellLayer = row.insertCell(row.length);
                        var cellLayerName = row.insertCell(row.length);
                        var cellBaseRoutes = row.insertCell(row.length);
                        var cellOptions = row.insertCell(row.length);
                        var cellCad = row.insertCell(row.length);
                        var cellIntermediate = row.insertCell(row.length);
                        var cellMask = row.insertCell(row.length);
                        var cellComment = row.insertCell(row.length);
                        var cellAttribute = row.insertCell(row.length);

                        cellLayerId.innerHTML = jsonData.AllLayers[key].Id;
                        cellLayer.innerHTML = jsonData.AllLayers[key].Layer;
                        cellLayerName.innerHTML = jsonData.AllLayers[key].Name;
                        cellBaseRoutes.innerHTML = jsonData.AllLayers[key].BaseRoutes;
                        cellOptions.innerHTML = jsonData.AllLayers[key].Options;
                        cellCad.innerHTML = jsonData.AllLayers[key].Cad;
                        cellIntermediate.innerHTML = jsonData.AllLayers[key].Intermediate;
                        cellMask.innerHTML = jsonData.AllLayers[key].Mask;
                        cellComment.innerHTML = jsonData.AllLayers[key].Comment;
                        cellAttribute.innerHTML = jsonData.AllLayers[key].Attribute;

                        var checkRow = Number.parseInt(cellCad.innerHTML) + Number.parseInt(cellIntermediate.innerHTML) + Number.parseInt(cellMask.innerHTML);
                        if (checkRow == 0 || checkRow > 1) {
                            row.setAttribute("class", "table-danger");
                        }
                    }

                    checkboxHideBaseRoutesLayersAllLayersTable.disabled = false;
                    checkboxHideOptLayersAllLayersTable.disabled = false;
                    checkboxHideCadLayersAllLayersTable.disabled = false;
                    checkboxHideIntermediateLayersAllLayersTable.disabled = false;
                    checkboxHideMaskLayersAllLayersTable.disabled = false;
                    checkboxHideCommentLayersAllLayersTable.disabled = false;

                    hideRowAllLayersTable();
                } else {
                    alertMsg("Не корректный ответ от сервера");
                }
            } catch (e) {
                alertMsg("Ошибка в структуре ответа от сайта:<br>" + e);
            }
        },
        error: function (request, status, error) {
            alertMsg("Ошибка при обращении к серверу:<br>error:" + error + "<br>status:" + status);
        }
    });
}

function getContentCadLayersLevel1() {

    clearTableCadLayers();
    var formData = new FormData(formRoutes);
    formData.append('queryId', 'getContentCadLayersLevel1');
    if (!formData.has("route")) {
        return false;
    }
    $.ajax({
        url: pathAjax.value,
        type: 'POST',
        data: formData,
        processData: false,
        contentType: false,
        success: function (data) {
            try {
                var jsonData = JSON.parse(data);
                if (typeof jsonData.AjaxError !== "undefined") {
                    alertMsg(jsonData.AjaxError);
                } else if (typeof jsonData.CadLayersLevel1 !== "undefined") {
                    var tbody = cadLayersTableLevel1.children[1];
                    for (var key in jsonData.CadLayersLevel1) {
                        var row = tbody.insertRow(tbody.rows.length);
                        var cellLayerId = row.insertCell(row.length);
                        var cellLayer = row.insertCell(row.length);
                        var cellLayerName = row.insertCell(row.length);
                        var cellCadLyaerId = row.insertCell(row.length);
                        var cellForbidingLyaerId = row.insertCell(row.length);
                        var cellSuspendedLayerId = row.insertCell(row.length);
                        var cellMergingLayerId = row.insertCell(row.length);
                        var cellMergingBase = row.insertCell(row.length);
                        var cellMergingDummy = row.insertCell(row.length);
                        cellLayerId.innerHTML = jsonData.CadLayersLevel1[key].LayerId;
                        cellLayer.innerHTML = jsonData.CadLayersLevel1[key].Layer;
                        cellLayerName.innerHTML = jsonData.CadLayersLevel1[key].LayerName;
                        cellCadLyaerId.innerHTML = jsonData.CadLayersLevel1[key].CadLayerId;
                        cellForbidingLyaerId.innerHTML = jsonData.CadLayersLevel1[key].ForbiddingLyaerId;
                        cellSuspendedLayerId.innerHTML = jsonData.CadLayersLevel1[key].SuspendedLayerId;
                        cellMergingLayerId.innerHTML = jsonData.CadLayersLevel1[key].MergingLayerId;
                        cellMergingBase.innerHTML = jsonData.CadLayersLevel1[key].MergingLayerBase;
                        cellMergingDummy.innerHTML = jsonData.CadLayersLevel1[key].MergingLayerDummy;
                    }
                    checkboxHideForbidingLayersCadLayersTableLevel1.disabled = false;
                    checkboxHideSuspendedLayersCadLayersTableLevel1.disabled = false;
                    checkboxHideMergingEmptyLayersCadLayersTableLevel1.disabled = false;
                    checkboxHideMergingBaseLayersCadLayersTableLevel1.disabled = false;
                    checkboxHideMergingDummyLayersCadLayersTableLevel1.disabled = false;

                    hideForbidingLayersCadLayersTableLevel1();
                    hideSuspendedLayersCadLayersTableLevel1();
                    hideMergingEmptyLayersCadLayersTableLevel1();
                    hideMergingBaseLayersCadLayersTableLevel1();
                    hideMergingDummyLayersCadLayersTableLevel1();

                    cadLayersTableLevel1.hidden = false;
                } else {
                    alertMsg("Не корректный ответ от сервера");
                }
            } catch (e) {
                alertMsg("Ошибка в структуре ответа от сайта:<br>" + e);
            }
        },
        error: function (request, status, error) {
            alertMsg("Ошибка при обращении к серверу:<br>error:" + error + "<br>status:" + status);
        }
    });
}

function getContentCadLayersLevel2() {

    clearTableCadLayers();
    var formData = new FormData(formRoutes);
    formData.append('queryId', 'getContentCadLayersLevel2');
    if (!formData.has("route")) {
        return false;
    }
    $.ajax({
        url: pathAjax.value,
        type: 'POST',
        data: formData,
        processData: false,
        contentType: false,
        success: function (data) {
            try {
                var jsonData = JSON.parse(data);
                if (typeof jsonData.AjaxError !== "undefined") {
                    alertMsg(jsonData.AjaxError);
                } else if (typeof jsonData.CadLayersLevel2 !== "undefined") {
                    var tbody = cadLayersTableLevel2.children[1];
                    for (var key in jsonData.CadLayersLevel2) {
                        var row = tbody.insertRow(tbody.rows.length);
                        var cellForbidingLayerName = row.insertCell(row.length);
                        var cellForbidingLayer = row.insertCell(row.length);
                        var cellForbidingLayerId = row.insertCell(row.length);
                        var cellMergingLayerName = row.insertCell(row.length);
                        var cellMergingLayer = row.insertCell(row.length);
                        var cellMergingLayerId = row.insertCell(row.length);

                        cellForbidingLayerName.innerHTML = jsonData.CadLayersLevel2[key].ForbiddingLayerName;
                        cellForbidingLayerId.innerHTML = jsonData.CadLayersLevel2[key].ForbiddingLayerId;
                        cellForbidingLayer.innerHTML = jsonData.CadLayersLevel2[key].ForbiddingLayer;
                        cellMergingLayerId.innerHTML = jsonData.CadLayersLevel2[key].MergingLayerId;
                        cellMergingLayer.innerHTML = jsonData.CadLayersLevel2[key].MergingLayer;
                        cellMergingLayerName.innerHTML = jsonData.CadLayersLevel2[key].MergingLayerName;
                    }
                    cadLayersTableLevel2.hidden = false;
                } else {
                    alertMsg("Не корректный ответ от сервера");
                }
            } catch (e) {
                alertMsg("Ошибка в структуре ответа от сайта:<br>" + e);
            }
        },
        error: function (request, status, error) {
            alertMsg("Ошибка при обращении к серверу:<br>error:" + error + "<br>status:" + status);
        }
    });
}

function getContentIntermediateLayersLevel1() {
    clearTableInetrmediateLayers();
    var formData = new FormData(formRoutes);
    formData.append('queryId', 'getContentIntermediatesLayersLevel1');
    if (!formData.has("route")) {
        return false;
    }
    $.ajax({
        url: pathAjax.value,
        type: 'POST',
        data: formData,
        processData: false,
        contentType: false,
        success: function (data) {
            try {
                var jsonData = JSON.parse(data);
                if (typeof jsonData.AjaxError !== "undefined") {
                    alertMsg(jsonData.AjaxError);
                } else if (typeof jsonData.IntermediatesLayersLevel1 !== "undefined") {
                    var tbody = intermediateLayersTableLevel1.children[1];
                    for (var key in jsonData.IntermediatesLayersLevel1) {
                        var row = tbody.insertRow(tbody.rows.length);
                        var cellLayerId = row.insertCell(row.length);
                        var cellLayer = row.insertCell(row.length);
                        var cellLayerName = row.insertCell(row.length);
                        var cellIntermediateLayerId = row.insertCell(row.length);
                        var cellIntermediateMark = row.insertCell(row.length);
                        var cellIntermediateDensity = row.insertCell(row.length);
                        cellLayerId.innerHTML = jsonData.IntermediatesLayersLevel1[key].LayerId;
                        cellLayer.innerHTML = jsonData.IntermediatesLayersLevel1[key].Layer;
                        cellLayerName.innerHTML = jsonData.IntermediatesLayersLevel1[key].LayerName;
                        cellIntermediateLayerId.innerHTML = jsonData.IntermediatesLayersLevel1[key].IntermediateLayerId;
                        cellIntermediateMark.innerHTML = jsonData.IntermediatesLayersLevel1[key].IntermediatesLayerMark;
                        cellIntermediateDensity.innerHTML = jsonData.IntermediatesLayersLevel1[key].IntermediatesDensity;
                    }

                    checkboxHideIntermediateEmptyLayersTableLevel1.disabled = false;
                    checkboxHideIntermediateMarkLayersTableLevel1.disabled = false;
                    checkboxHideIntermediateDensityLayersTableLevel1.disabled = false;

                    hideIntermediateEmptyLayersTableLevel1();
                    hideIntermediateMarkLayersTableLevel1();
                    hideIntermediateDensityLayersTableLevel1();

                    intermediateLayersTableLevel1.hidden = false;
                } else {
                    alertMsg("Не корректный ответ от сервера");
                }
            } catch (e) {
                alertMsg("Ошибка в структуре ответа от сайта:<br>" + e);
            }
        },
        error: function (request, status, error) {
            alertMsg("Ошибка при обращении к серверу:<br>error:" + error + "<br>status:" + status);
        }
    });
}

function getContentIntermediateLayersLevel2() {

    clearTableInetrmediateLayers();
    var formData = new FormData(formRoutes);
    formData.append('queryId', 'getContentIntermediatesLayersLevel2');
    if (!formData.has("route")) {
        return false;
    }
    $.ajax({
        url: pathAjax.value,
        type: 'POST',
        data: formData,
        processData: false,
        contentType: false,
        success: function (data) {
            try {
                var jsonData = JSON.parse(data);
                if (typeof jsonData.AjaxError !== "undefined") {
                    alertMsg(jsonData.AjaxError);
                } else if (typeof jsonData.IntermediateLayersLevel2 !== "undefined") {
                    var tbody = intermediateLayersTableLevel2.children[1];
                    for (var key in jsonData.IntermediateLayersLevel2) {
                        var row = tbody.insertRow(tbody.rows.length);
                        var cellMergingLayerName = row.insertCell(row.length);
                        var cellMergingLayer = row.insertCell(row.length);
                        var cellMergingLayerId = row.insertCell(row.length);
                        var cellIntermediateLayerName = row.insertCell(row.length);
                        var cellIntermediateLayer = row.insertCell(row.length);
                        var cellIntermediateLayerId = row.insertCell(row.length);

                        cellIntermediateLayerName.innerHTML = jsonData.IntermediateLayersLevel2[key].IntermediateLayerName;
                        cellIntermediateLayer.innerHTML = jsonData.IntermediateLayersLevel2[key].IntermediateLayerId;
                        cellIntermediateLayerId.innerHTML = jsonData.IntermediateLayersLevel2[key].IntermediateLayer;
                        cellMergingLayerId.innerHTML = jsonData.IntermediateLayersLevel2[key].MergingLayerId;
                        cellMergingLayer.innerHTML = jsonData.IntermediateLayersLevel2[key].MergingLayer;
                        cellMergingLayerName.innerHTML = jsonData.IntermediateLayersLevel2[key].MergingLayerName;
                    }
                    intermediateLayersTableLevel2.hidden = false;
                } else {
                    alertMsg("Не корректный ответ от сервера");
                }
            } catch (e) {
                alertMsg("Ошибка в структуре ответа от сайта:<br>" + e);
            }
        },
        error: function (request, status, error) {
            alertMsg("Ошибка при обращении к серверу:<br>error:" + error + "<br>status:" + status);
        }
    });
}

function getContentMaskLayersLevel1() {
    clearTableMaskLayers();
    var formData = new FormData(formRoutes);
    formData.append('queryId', 'getContentMaskLayersLevel1');
    if (!formData.has("route")) {
        return false;
    }
    $.ajax({
        url: pathAjax.value,
        type: 'POST',
        data: formData,
        processData: false,
        contentType: false,
        success: function (data) {
            try {
                var jsonData = JSON.parse(data);
                if (typeof jsonData.AjaxError !== "undefined") {
                    alertMsg(jsonData.AjaxError);
                } else if (typeof jsonData.MasksLayersLevel1 !== "undefined") {
                    var tbody = maskLayersTableLevel1.children[1];
                    for (var key in jsonData.MasksLayersLevel1) {
                        var row = tbody.insertRow(tbody.rows.length);
                        var cellLayerId = row.insertCell(row.length);
                        var cellLayer = row.insertCell(row.length);
                        var cellLayerName = row.insertCell(row.length);
                        var cellMaskLayerId = row.insertCell(row.length);
                        var cellMaskMark = row.insertCell(row.length);

                        cellLayerId.innerHTML = jsonData.MasksLayersLevel1[key].LayerId;
                        cellLayer.innerHTML = jsonData.MasksLayersLevel1[key].Layer;
                        cellLayerName.innerHTML = jsonData.MasksLayersLevel1[key].LayerName;
                        cellMaskLayerId.innerHTML = jsonData.MasksLayersLevel1[key].MaskLayerId;
                        cellMaskMark.innerHTML = jsonData.MasksLayersLevel1[key].MaskLayerMark;

                    }

                    checkboxHideMaskEmptyLayersTableLevel1.disabled = false;
                    checkboxHideMaskMarkLayersTableLevel1.disabled = false;

                    hideMaskEmptyLayersTableLevel1();
                    hideMaskMarkLayersTableLevel1();

                    maskLayersTableLevel1.hidden = false;
                } else {
                    alertMsg("Не корректный ответ от сервера");
                }
            } catch (e) {
                alertMsg("Ошибка в структуре ответа от сайта:<br>" + e);
            }
        },
        error: function (request, status, error) {
            alertMsg("Ошибка при обращении к серверу:<br>error:" + error + "<br>status:" + status);
        }
    });
}

function getContentMaskLayersLevel2() {
    clearTableMaskLayers()
    var formData = new FormData(formRoutes);
    formData.append('queryId', 'getContentMaskLayersLevel2');
    if (!formData.has("route")) {
        return false;
    }
    $.ajax({
        url: pathAjax.value,
        type: 'POST',
        data: formData,
        processData: false,
        contentType: false,
        success: function (data) {
            try {
                var jsonData = JSON.parse(data);
                if (typeof jsonData.AjaxError !== "undefined") {
                    alertMsg(jsonData.AjaxError);
                } else if (typeof jsonData.MaskLayersLevel2 !== "undefined") {
                    var tbody = maskLayersTableLevel2.children[1];
                    for (var key in jsonData.MaskLayersLevel2) {
                        var row = tbody.insertRow(tbody.rows.length);
                        var cellIntermediateLayerName = row.insertCell(row.length);
                        var cellIntermediateLayer = row.insertCell(row.length);
                        var cellIntermediateLayerId = row.insertCell(row.length);
                        var cellMaskLayerName = row.insertCell(row.length);
                        var cellMaskLayer = row.insertCell(row.length);
                        var cellMaskLayerId = row.insertCell(row.length);

                        cellIntermediateLayerName.innerHTML = jsonData.MaskLayersLevel2[key].IntermediateLayerName;
                        cellIntermediateLayer.innerHTML = jsonData.MaskLayersLevel2[key].IntermediateLayer;
                        cellIntermediateLayerId.innerHTML = jsonData.MaskLayersLevel2[key].IntermediateLayerId;
                        cellMaskLayerId.innerHTML = jsonData.MaskLayersLevel2[key].MaskLayerId;
                        cellMaskLayer.innerHTML = jsonData.MaskLayersLevel2[key].MaskLayer;
                        cellMaskLayerName.innerHTML = jsonData.MaskLayersLevel2[key].MaskLayerName;
                    }
                    maskLayersTableLevel2.hidden = false;
                } else {
                    alertMsg("Не корректный ответ от сервера");
                }
            } catch (e) {
                alertMsg("Ошибка в структуре ответа от сайта:<br>" + e);
            }
        },
        error: function (request, status, error) {
            alertMsg("Ошибка при обращении к серверу:<br>error:" + error + "<br>status:" + status);
        }
    });
}

function getRoute() {
    clearRoute();
    var formData = new FormData(formTechnology);
    formData.append('queryId', 'getRoute');
    if (formData.get("technology") == "...") {
        return false;
    }
    $.ajax({
        url: pathAjax.value,
        type: 'POST',
        data: formData,
        processData: false,
        contentType: false,
        success: function (data) {
            try {
                var jsonData = JSON.parse(data);
                if (typeof jsonData.AjaxError !== "undefined") {
                    alertMsg(jsonData.AjaxError);
                } else if (typeof jsonData.RouteList !== "undefined") {
                    if (Object.keys(jsonData.RouteList).length > 0) {
                        for (var key in jsonData.RouteList) {
                            createBaseRouteRadiokBox(routesCheckbox, "baseRoute_" + jsonData.RouteList[key].Id, jsonData.RouteList[key].Id, jsonData.RouteList[key].Name);
                        }
                    } else {
                        var div = document.createElement("div");
                        div.setAttribute("class", "alert alert-warning");
                        div.innerHTML = "Данных нет";
                        routesCheckbox.appendChild(div);
                    }
                } else {
                    alertMsg("Не корректный ответ от сервера");
                }
            } catch (e) {
                alertMsg("Ошибка в структуре ответа от сайта:<br>" + e);
            }
        },
        error: function (request, status, error) {
            alertMsg("Ошибка при обращении к серверу:<br>error:" + error + "<br>status:" + status);
        }
    });
}

function getRouteContent() {
    getContentCadLayersLevel1();
    getContentCadLayersLevel2();
    getContentIntermediateLayersLevel1();
    getContentIntermediateLayersLevel2();
    getContentMaskLayersLevel1();
    getContentMaskLayersLevel2();
}

function getTechnologyList() {
    clearRoute();
    technologySelect.innerHTML = "";
    technologySelect.disabled = true;
    var formData = new FormData();
    formData.append('queryId', 'getTechnologyList');
    $.ajax({
        url: pathAjax.value,
        type: 'POST',
        data: formData,
        processData: false,
        contentType: false,
        success: function (data) {
            try {
                var jsonData = JSON.parse(data);
                if (typeof jsonData.AjaxError !== "undefined") {
                    alertMsg(jsonData.AjaxError);
                } else if (typeof jsonData.TechnologyList !== "undefined") {
                    technologySelect.innerHTML = "";
                    var opt = document.createElement("option");
                    opt.text = "...";
                    opt.selected = true;
                    technologySelect.appendChild(opt);
                    for (var key in jsonData.TechnologyList) {
                        var opt = document.createElement("option");
                        opt.text = jsonData.TechnologyList[key].Name;
                        opt.value = jsonData.TechnologyList[key].Id;
                        technologySelect.appendChild(opt);
                    }
                    technologySelect.disabled = false;
                } else {
                    alertMsg("Не корректный ответ от сервера");
                }
            } catch (e) {
                alertMsg("Ошибка в структуре ответа от сайта:<br>" + e);
            }
        },
        error: function (request, status, error) {
            alertMsg("Ошибка при обращении к серверу:<br>error:" + error + "<br>status:" + status);
        }
    });
}

function hideRowAllLayersTable() {
    var tbody = allLayersTable.children[1];
    for (var i = 0; i < tbody.children.length; i++) {
        var row = tbody.children[i];
        var cellBR = row.children[3];
        var cellOPT = row.children[4];
        var cellCAD = row.children[5];
        var cellINTRM = row.children[6];
        var cellMASK = row.children[7];
        var cellCOMMENT = row.children[8];
        var flagRowHidden = false;

        if (checkboxHideBaseRoutesLayersAllLayersTable.checked && cellBR.innerHTML == "") {
            flagRowHidden = true;
        }

        if (checkboxHideOptLayersAllLayersTable.checked && cellOPT.innerHTML == "") {
            flagRowHidden = true;
        }

        if (checkboxHideCadLayersAllLayersTable.checked && cellCAD.innerHTML == "1") {
            flagRowHidden = true;
        }

        if (checkboxHideIntermediateLayersAllLayersTable.checked && cellINTRM.innerHTML == "1") {
            flagRowHidden = true;
        }

        if (checkboxHideMaskLayersAllLayersTable.checked && cellMASK.innerHTML == "1") {
            flagRowHidden = true;
        }

        if (checkboxHideCommentLayersAllLayersTable.checked && cellCOMMENT.innerHTML == "") {
            flagRowHidden = true;
        }

        row.hidden = flagRowHidden;
    }
}



function hideCheckEmptyRowAllLayersTableLevel() {
    var tbody = allLayersTable.children[1];
    for (var i = 0; i < tbody.children.length; i++) {
        var row = tbody.children[i];
        var flagEmptyRow = true;
        for (var j = 3; j <= 8; j++) {
            var cell = row.children[j];
            if (!cell.hidden && cell.innerHTML != "") {
                flagEmptyRow = false;
            }
        }
        if (flagEmptyRow) {
            row.hidden = true;
        } else {
            row.hidden = false;
        }
    }
}

function hideCheckEmptyRowCadLayersTableLevel1() {
    var tbody = cadLayersTableLevel1.children[1];
    for (var i = 0; i < tbody.children.length; i++) {
        var row = tbody.children[i];
        var flagEmptyRow = true;
        for (var j = 4; j <= 6; j++) {
            var cell = row.children[j];
            if (!cell.hidden && cell.innerHTML != "") {
                flagEmptyRow = false;
            }
        }
        if (flagEmptyRow) {
            row.hidden = true;
        } else {
            row.hidden = false;
        }
    }
}

function hideCheckEmptyRowIntermediateLayersTableLevel1() {
    var tbody = intermediateLayersTableLevel1.children[1];
    for (var i = 0; i < tbody.children.length; i++) {
        var row = tbody.children[i];
        var flagEmptyRow = true;
        for (var j = 3; j <= 5; j++) {
            var cell = row.children[j];
            if (!cell.hidden && cell.innerHTML != "") {
                flagEmptyRow = false;
            }
        }
        if (flagEmptyRow) {
            row.hidden = true;
        } else {
            row.hidden = false;
        }
    }
}

function hideCheckEmptyRowMaskLayersTableLevel1() {
    var tbody = maskLayersTableLevel1.children[1];
    for (var i = 0; i < tbody.children.length; i++) {
        var row = tbody.children[i];
        var flagEmptyRow = true;
        for (var j = 3; j <= 4; j++) {
            var cell = row.children[j];
            if (!cell.hidden && cell.innerHTML != "") {
                flagEmptyRow = false;
            }
        }
        if (flagEmptyRow) {
            row.hidden = true;
        } else {
            row.hidden = false;
        }
    }
}

function hideForbidingLayersCadLayersTableLevel1() {
    var thead = cadLayersTableLevel1.children[0];
    var tbody = cadLayersTableLevel1.children[1];
    thead.children[0].children[4].hidden = checkboxHideForbidingLayersCadLayersTableLevel1.checked;
    thead.children[1].children[0].hidden = checkboxHideForbidingLayersCadLayersTableLevel1.checked;
    for (var i = 0; i < tbody.children.length; i++) {
        var row = tbody.children[i];
        var cell = row.children[4];
        cell.hidden = checkboxHideForbidingLayersCadLayersTableLevel1.checked;
    }
    hideCheckEmptyRowCadLayersTableLevel1();
}

function hideIntermediateEmptyLayersTableLevel1() {
    var thead = intermediateLayersTableLevel1.children[0];
    var tbody = intermediateLayersTableLevel1.children[1];

    if (checkboxHideIntermediateEmptyLayersTableLevel1.checked && checkboxHideIntermediateMarkLayersTableLevel1.checked && checkboxHideIntermediateDensityLayersTableLevel1.checked) {
        thead.children[0].children[3].hidden = true;
        thead.children[1].children[0].hidden = true;
    } else {
        thead.children[0].children[3].hidden = false;
        thead.children[1].children[0].hidden = false;
    }
    for (var i = 0; i < tbody.children.length; i++) {
        var row = tbody.children[i];
        var cell1 = row.children[3];
        var cell2 = row.children[4];
        var cell3 = row.children[5];
        if (cell2.innerHTML == "" && cell3.innerHTML == "" && cell1.innerHTML != "") {
            cell1.hidden = checkboxHideIntermediateEmptyLayersTableLevel1.checked;
        }
    }

    hideCheckEmptyRowIntermediateLayersTableLevel1();
}

function hideIntermediateMarkLayersTableLevel1() {
    var thead = intermediateLayersTableLevel1.children[0];
    var tbody = intermediateLayersTableLevel1.children[1];

    if (checkboxHideIntermediateEmptyLayersTableLevel1.checked && checkboxHideIntermediateMarkLayersTableLevel1.checked && checkboxHideIntermediateDensityLayersTableLevel1.checked) {
        thead.children[0].children[3].hidden = true;
        thead.children[1].children[0].hidden = true;
    } else {
        thead.children[0].children[3].hidden = false;
        thead.children[1].children[0].hidden = false;
    }
    thead.children[1].children[1].hidden = checkboxHideIntermediateMarkLayersTableLevel1.checked;
    for (var i = 0; i < tbody.children.length; i++) {
        var row = tbody.children[i];
        var cell1 = row.children[3];
        var cell2 = row.children[4];
        var cell3 = row.children[5];
        if (cell2.innerHTML != "" && cell3.innerHTML == "") {
            cell1.hidden = checkboxHideIntermediateMarkLayersTableLevel1.checked;
            cell3.hidden = checkboxHideIntermediateMarkLayersTableLevel1.checked;
        }
        cell2.hidden = checkboxHideIntermediateMarkLayersTableLevel1.checked;
    }
    hideCheckEmptyRowIntermediateLayersTableLevel1();
}

function hideIntermediateDensityLayersTableLevel1() {
    var thead = intermediateLayersTableLevel1.children[0];
    var tbody = intermediateLayersTableLevel1.children[1];

    if (checkboxHideIntermediateEmptyLayersTableLevel1.checked && checkboxHideIntermediateMarkLayersTableLevel1.checked && checkboxHideIntermediateDensityLayersTableLevel1.checked) {
        thead.children[0].children[3].hidden = true;
        thead.children[1].children[0].hidden = true;
    } else {
        thead.children[0].children[3].hidden = false;
        thead.children[1].children[0].hidden = false;
    }
    thead.children[1].children[2].hidden = checkboxHideIntermediateDensityLayersTableLevel1.checked;
    for (var i = 0; i < tbody.children.length; i++) {
        var row = tbody.children[i];
        var cell1 = row.children[3];
        var cell2 = row.children[4];
        var cell3 = row.children[5];
        if (cell3.innerHTML != "" && cell2.innerHTML == "") {
            cell1.hidden = checkboxHideIntermediateDensityLayersTableLevel1.checked;
            cell2.hidden = checkboxHideIntermediateDensityLayersTableLevel1.checked;
        }
        cell3.hidden = checkboxHideIntermediateDensityLayersTableLevel1.checked;
    }
    hideCheckEmptyRowIntermediateLayersTableLevel1();
}

function hideMaskEmptyLayersTableLevel1() {
    var thead = maskLayersTableLevel1.children[0];
    var tbody = maskLayersTableLevel1.children[1];

    if (checkboxHideMaskEmptyLayersTableLevel1.checked && checkboxHideMaskMarkLayersTableLevel1.checked) {
        thead.children[0].children[3].hidden = true;
        thead.children[1].children[0].hidden = true;
    } else {
        thead.children[0].children[3].hidden = false;
        thead.children[1].children[0].hidden = false;
    }
    for (var i = 0; i < tbody.children.length; i++) {
        var row = tbody.children[i];
        var cell1 = row.children[3];
        var cell2 = row.children[4];
        if (cell2.innerHTML == "" && cell1.innerHTML != "") {
            cell1.hidden = checkboxHideMaskEmptyLayersTableLevel1.checked;
        }
    }
    hideCheckEmptyRowMaskLayersTableLevel1();
}

function hideMaskMarkLayersTableLevel1() {
    var thead = maskLayersTableLevel1.children[0];
    var tbody = maskLayersTableLevel1.children[1];

    if (checkboxHideMaskEmptyLayersTableLevel1.checked && checkboxHideMaskMarkLayersTableLevel1.checked) {
        thead.children[0].children[3].hidden = true;
        thead.children[1].children[0].hidden = true;
    } else {
        thead.children[0].children[3].hidden = false;
        thead.children[1].children[0].hidden = false;
    }
    thead.children[1].children[1].hidden = checkboxHideMaskMarkLayersTableLevel1.checked;
    for (var i = 0; i < tbody.children.length; i++) {
        var row = tbody.children[i];
        var cell1 = row.children[3];
        var cell2 = row.children[4];
        if (cell2.innerHTML != "") {
            cell1.hidden = checkboxHideMaskMarkLayersTableLevel1.checked;
        }
        cell2.hidden = checkboxHideMaskMarkLayersTableLevel1.checked;
    }
    hideCheckEmptyRowMaskLayersTableLevel1();
}

function hideMergingEmptyLayersCadLayersTableLevel1() {
    var thead = cadLayersTableLevel1.children[0];
    var tbody = cadLayersTableLevel1.children[1];

    if (checkboxHideMergingEmptyLayersCadLayersTableLevel1.checked && checkboxHideMergingBaseLayersCadLayersTableLevel1.checked && checkboxHideMergingDummyLayersCadLayersTableLevel1.checked) {
        thead.children[0].children[6].hidden = true;
        thead.children[1].children[2].hidden = true;
    } else {
        thead.children[0].children[6].hidden = false;
        thead.children[1].children[2].hidden = false;
    }
    for (var i = 0; i < tbody.children.length; i++) {
        var row = tbody.children[i];
        var cell1 = row.children[6];
        var cell2 = row.children[7];
        var cell3 = row.children[8];
        if (cell2.innerHTML == "" && cell3.innerHTML == "" && cell1.innerHTML != "") {
            cell1.hidden = checkboxHideMergingEmptyLayersCadLayersTableLevel1.checked;
        }
    }
    hideCheckEmptyRowCadLayersTableLevel1();
}

function hideMergingBaseLayersCadLayersTableLevel1() {
    var thead = cadLayersTableLevel1.children[0];
    var tbody = cadLayersTableLevel1.children[1];

    if (checkboxHideMergingEmptyLayersCadLayersTableLevel1.checked && checkboxHideMergingBaseLayersCadLayersTableLevel1.checked && checkboxHideMergingDummyLayersCadLayersTableLevel1.checked) {
        thead.children[0].children[6].hidden = true;
        thead.children[1].children[2].hidden = true;
    } else {
        thead.children[0].children[6].hidden = false;
        thead.children[1].children[2].hidden = false;
    }
    thead.children[1].children[3].hidden = checkboxHideMergingBaseLayersCadLayersTableLevel1.checked;
    for (var i = 0; i < tbody.children.length; i++) {
        var row = tbody.children[i];
        var cell1 = row.children[6];
        var cell2 = row.children[7];
        var cell3 = row.children[8];
        if (cell2.innerHTML != "") {
            cell1.hidden = checkboxHideMergingBaseLayersCadLayersTableLevel1.checked;
            cell3.hidden = checkboxHideMergingBaseLayersCadLayersTableLevel1.checked;
        }
        cell2.hidden = checkboxHideMergingBaseLayersCadLayersTableLevel1.checked;
    }
    hideCheckEmptyRowCadLayersTableLevel1();
}

function hideMergingDummyLayersCadLayersTableLevel1() {
    var thead = cadLayersTableLevel1.children[0];
    var tbody = cadLayersTableLevel1.children[1];

    if (checkboxHideMergingEmptyLayersCadLayersTableLevel1.checked && checkboxHideMergingBaseLayersCadLayersTableLevel1.checked && checkboxHideMergingDummyLayersCadLayersTableLevel1.checked) {
        thead.children[0].children[6].hidden = true;
        thead.children[1].children[2].hidden = true;
    } else {
        thead.children[0].children[6].hidden = false;
        thead.children[1].children[2].hidden = false;
    }
    thead.children[1].children[4].hidden = checkboxHideMergingDummyLayersCadLayersTableLevel1.checked;
    for (var i = 0; i < tbody.children.length; i++) {
        var row = tbody.children[i];
        var cell1 = row.children[6];
        var cell2 = row.children[7];
        var cell3 = row.children[8];
        if (cell3.innerHTML != "") {
            cell1.hidden = checkboxHideMergingDummyLayersCadLayersTableLevel1.checked;
            cell2.hidden = checkboxHideMergingDummyLayersCadLayersTableLevel1.checked;
        }
        cell3.hidden = checkboxHideMergingDummyLayersCadLayersTableLevel1.checked;
    }
    hideCheckEmptyRowCadLayersTableLevel1();
}

function hideSuspendedLayersCadLayersTableLevel1() {
    var thead = cadLayersTableLevel1.children[0];
    var tbody = cadLayersTableLevel1.children[1];
    thead.children[0].children[5].hidden = checkboxHideSuspendedLayersCadLayersTableLevel1.checked;
    thead.children[1].children[1].hidden = checkboxHideSuspendedLayersCadLayersTableLevel1.checked;
    for (var i = 0; i < tbody.children.length; i++) {
        var row = tbody.children[i];
        var cell = row.children[5];
        cell.hidden = checkboxHideSuspendedLayersCadLayersTableLevel1.checked;
    }
    hideCheckEmptyRowCadLayersTableLevel1();
}

window.onload = function () {
    layersPage.setAttribute("class", "nav-item nav-link active");
    technologySelect.disabled = true;
    getTechnologyList();
};