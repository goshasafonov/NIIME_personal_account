<?php
$db_mysql_user_login = "php_checkDB_v2";
$db_mysql_user_paswd = "XH55bf5d5y5SbThA";
$db_mysql_database = "newOPFSHV2";
$db_mysql_host = "aryabinin";
$db_mysql_server = mysql_connect($db_mysql_host, $db_mysql_user_login, $db_mysql_user_paswd);

mysql_set_charset('utf8');
if (!$db_mysql_server) {
    $msg['AjaxError'] = "Невозможно подключиться к MySQL, обратитесь к администратору. Код ошибки-1";
} else {
    mysql_select_db($db_mysql_database) or $msg['AjaxError'] = "Невозможно подключиться к базе данных MySQL, обратитесь к администратору.  Код ошибки-2";
}
?>
