window.onload = function () {
    releaseNotesPage.setAttribute("class", "nav-item nav-link active");
}