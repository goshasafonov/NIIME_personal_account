<?php
$mysqli = new mysqli($db_mysql_host, $db_mysql_user_login, $db_mysql_user_paswd, $db_mysql_database);

if ($mysqli->connect_errno) {
    $msg['AjaxError'] = "Извините, возникла проблема на сайте<br>"
            . "Ошибка: Не удалась создать соединение с базой MySQL и вот почему: <br>"
            . "Номер ошибки: " . $mysqli->connect_errno . "<br>"
            . "Ошибка: " . $mysqli->connect_error . "<br>";
    echo json_encode($msg);
    exit;
}

if (!$mysqli->set_charset("utf8")) {
    $msg["AjaxError"] = $time . ": Ошибка при загрузке набора символов utf8. Обратитесь к администратору.";    
    echo json_encode($msg);
    exit;
}

?>
